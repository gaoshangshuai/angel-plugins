// Angel Live 插件：优酷直播 v1.0.1
// 目标站点：https://live.youku.com （会 302 到 www.youku.com/ku/weblive）
//
// 数据源（2026-11-25 实测可用）：
//   ① 频道清单：www.youku.com/ku/weblive 的 SSR HTML，正则解析
//      ilproom?id=<liveId> + aria-label="标题" + data-src="封面" → 60 个直播间
//   ② 取流主路径：公网中转 GET /yk/<SK>/play/<liveId>?sharecode=...
//      → {"url":"https://lvo-live.youku.com/...m3u8?...cdnQuality=720p..."}（约 6 小时有效）
//      中转在服务端完成 MTOP 令牌申领 + md5 签名 + ckey 续期，设备端只发一个普通 GET
//   ③ 取流兜底：直连 acs.youku.com MTOP 网关
//      liveplaycontrol 4.0 + 内置 ckey 轮换 + _m_h5_tk 令牌签名（设备网络受限时可能失败）
//   ④ 房间信息：纯本地（内置经典白名单 + SSR 缓存），不阻塞 UI；
//      fullinfo 接口仅在需要标题时可选启用，此处为保证秒开未调用
//
// 与 XPTV 版的关键差异：导出对象改成 globalThis.LiveParsePlugin，
// 网络从 $fetch 换成 Host.http.request，返回体换成宿主 DTO 结构。

var _yk_platformId = "youku";
var _yk_liveType = "0";
var _yk_ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
var _yk_referer = "https://live.youku.com/";
var _yk_homeURL = "https://www.youku.com/ku/weblive";
var _yk_pageURL = "https://live.youku.com";

// 取流中转服务（主路径）。RELAY + "/play/<liveId>" + RELAY_QS 即完整地址。
var _yk_relay = "https://youku-ckey-service.app.workbuddy.host/yk/a3f7c29e51b8d640";
var _yk_relayQS = "?sharecode=TTQUPYMAC5";

// MTOP 兜底参数
var _yk_appKey = "24679788";
var _yk_cna = "defaultCnaLive20180425";
var _yk_ckeys = [
  "140#mtOxT6srzzZ00zo23zau4pN8s9DtMz5PDYGWZ2BK/+/Zq0BpigB0sD2RQfIzGs5kPVb223hqzzcWHLxZ+orzzZVr9jWqlbrz2DD3V3gqzbaR2F+Jlp1xzoObV2EqlVrcfTDI1wba7X53xYYCTdkWsdWCFOPVQLmJpd6Kb0pCu8W1zMbv7EmzZh0z3f/EGPkFHoM3loZQEurkEk/Ry+7VNAFA3kyzjZFU5EBsg1bpjDxOeZ+eOJ7qtcs3aAWysdWTDF6uH/awUOZlJNBSPxdob/dNPN9cGST4Ik59zUAXNHkStaTHD2OamJ35+f51T+A9wMjKdpSnQvf6GUX+RXKYouKL5ecHdgicgvltQN8cHDNTueL6WcLUE7WcQVGPqc/svhqp75zog65Fo3QUwdiHyUBekmKvLf1RlT9oz32GPb6+N1zrv6A17BHZ48tcRaUMhE+O5PV+HWqzstPYZTvKimB+JMdA3PQ5kZTFLvy/IB+MJBKOrb6q/UTqF/YbbIPVV2KHXTnCqlsxr4YAVSiRYxBAXnVYSU4GkfrVAV3OK/PbTf+cPAPNQHA8WFkm+F==",
  "140#LJfoxts2zzWjhQo23zau4pN8s9DtMz5PDYGWZ2BK/+/Zq0BpigB0sD2RQfIzGs5kPVO2+3hqzzcWHLxZ+orzzXIcIY4qlQzx2DD3VthqzFFa0XQDTUzszPziVP//lbzx2oFnlT8I1wba7X53xYYCTdkWsdWE5CTH83TmqZ5i6ePaeMrfG7v3zv0bJW4zZh0z3f/EGPkFHoM3UzQ1UZVUUckqHKi+hCkUb3cN+Di/XVQGEbA1Fs30tXV5ATxhmq4ycSuARiTLQjuwd0SF3D4RlIoE1nSt2BJ1e6hfgMdt3sP+byOe6tQLeKZlGqyUqwAX0CR0zIfgYDVe2uioYxdE0+U/rGtdXRBcg1RB+XzQBFT4dDNQBs7jdtLOOP9aV0SuA9Z0v2wQTOimIWZJeeT4qlPoPqzMrpr8ULOp/dPQ73sCi0oi0oM+xh8zSuItypaRy0xqNnYC2J28rclvwaGycLcCsO5Mma926WmPg2kWEyB/NopPNpZxU+3Tuo0q67J5Iwqn67lfI+Luhu4vtSZfriDfpB30uCQPESNr3yq4Vh/w6r0EMX1oA8PjMZX+HusyLtPOe5CSjpVbEsarpcbw//OHeQnZGU7uyhhsGF1xlkubvGVj7ToDazKrKzDbouR9l2aHVi4mg/DFYXBZGWOGhdcdRtc8MVnS5ioQ3bK8CaG0qxqT7poDXS4lqPf2tBUoWF==",
  "140#2gfoo6sZzzWm2zo23zau4pN8s9DtMz5PDYGWZ2BK/+/Zq0BpigB0sD2RQfIzGs5kPIr2K6hqzzcWHLxZ+orzzZF2VHWqlQzx2DD3VthqzFfa0XQDTUzsvnQiVXE/tFzx2Dc33z//EHmijDapVrMn79/QCGKQA44d/Q72lQpGncnlAH7CFZW0NubDw2q6+TxnNXzeZg4ymGzO4FlXooVRc4BXBG1OYrEp/hjzMj1QHd6I4ovKxCiDQUReI4dCQnsp1kfjZ5A0nQvx95XwjZzM26vq244bqZMiNgVClpWgFAMU528DwVCelzvt00GSm+1Bh2m60fq70G52HK1Y8KL55LBWP5hrdvjWlLrYisIIeQrUK8YeGzWRcPLIP/GspVpLoei6pM+BP822MGOEC2/oAkPDXQZsn7hSlK9HVdEbtQ+TpwObRV8s9wMIdVROQfK8vn8NheT5Oo9iCOSqngKLtW32vO0Ou7tZnX2MWbSFrdf6mapr4fVhuZQ7Zdiqqp6f70/xwRNI9gpEvugyNERiSiw2y0I/uWYv/+fXMazyqyBng7+xKBoCW6cPtS+3tUHSWw56ALy86Wrf843BSVtmfqG2Q064jnpjEa2X14pu5IYTJJ8vWpd/pZ9U+4zz4CO7Y426eULu+BzGJBe6q1phrquSwlh4TjqDsh1nunEHXN3MdoDMnIFgxQ9yqSqMvZkwzMjv/Z2q"
];

// 经典直播白名单：零网络依赖的默认列表，SSR 失败时也不会白屏。
// [liveId, 标题, 封面]（2026-11-25 逐个实测可取 720P 流）
var _yk_classic = [
  ["8175820", "卫视热播·放映厅", "https://live.ykimg.com/image/57995ABD8B8047E180A010265864B41B"],
  ["8175819", "中国通史·央视全集", "https://live.ykimg.com/image/A214870AA03B47BA8B5F077B2E1D7D14"],
  ["8184633", "百家讲坛·名师荟萃", "https://live.ykimg.com/image/441FED95C3B94BC2B56BD2871B761AD3"],
  ["8184638", "典籍中国·央视精品", "https://live.ykimg.com/image/673F126930F340ACA1E76B3FF2DA63A2"],
  ["8184635", "戏曲大全·国粹精华", "https://live.ykimg.com/image/1EB9CBE988024CCA8FC0A049A0BFB90D"],
  ["8176119", "语言启蒙娃娃抓起", "https://live.ykimg.com/image/40E88E2F605E4331B16CDACB2BBC5F90"]
];

// SSR 频道缓存（同一 JS 上下文内复用，避免每屏都拉 441KB HTML）
var _yk_channelCache = [];
var _yk_channelsLoaded = false;
var _yk_lastPlayFail = "";

// ==================== 基础工具 ====================

function _yk_str(value) {
  return value === undefined || value === null ? "" : String(value);
}

function _yk_throw(code, message, context) {
  var ctx = context || {};
  if (globalThis.Host && typeof Host.raise === "function") {
    Host.raise(code, message, ctx);
  }
  if (globalThis.Host && typeof Host.makeError === "function") {
    throw Host.makeError(code || "UNKNOWN", message || "", ctx);
  }
  throw new Error("LP_PLUGIN_ERROR:" + JSON.stringify({
    code: String(code || "UNKNOWN"),
    message: String(message || ""),
    context: ctx
  }));
}

function _yk_unescape(s) {
  return _yk_str(s)
    .replace(/&amp;/g, "&").replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'").replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">").replace(/&nbsp;/g, " ");
}

// 从房间号、分享链接、直播间 URL 里提取 liveId
function _yk_extractId(input) {
  var t = _yk_str(input).trim();
  if (!t) return "";
  if (/^\d{5,10}$/.test(t)) return t;
  var m = t.match(/[?&]id=(\d{5,10})/);
  if (m) return m[1];
  m = t.match(/ilproom[^\d]*(\d{5,10})/);
  if (m) return m[1];
  m = t.match(/(\d{5,10})/);
  return m ? m[1] : "";
}

function _yk_requireId(payload, field) {
  var id = _yk_extractId(payload && payload.roomId);
  if (!id) _yk_throw("INVALID_ARGS", "roomId is required", { field: field || "roomId" });
  return id;
}

// ==================== 宿主网络层 ====================

// Host.http.request({url,method,headers,timeout}) → {status,headers,setCookies,bodyText}
async function _yk_request(options) {
  if (!globalThis.Host || !Host.http || typeof Host.http.request !== "function") {
    _yk_throw("UNSUPPORTED", "Host.http.request is unavailable", {});
  }
  var raw = await Host.http.request({
    url: options.url,
    method: options.method || "GET",
    headers: Object.assign({
      "User-Agent": _yk_ua,
      "Referer": _yk_referer,
      "Accept": "application/json, text/plain, */*",
      "Accept-Language": "zh-CN,zh;q=0.9"
    }, options.headers || {}),
    timeout: options.timeout || 20
  });
  // 宿主多数情况直接给对象；若给 JSON 字符串也兼容
  var res = raw;
  if (typeof raw === "string") {
    try { res = JSON.parse(raw); } catch (e) { res = null; }
  }
  if (!res) _yk_throw("UPSTREAM", "empty http response", { url: options.url });
  var status = Number(res.status || res.statusCode) || 0;
  if (status >= 400) _yk_throw("UPSTREAM", "youku HTTP " + status, { url: options.url, status: String(status) });
  return res;
}

function _yk_body(res) {
  return _yk_str(res && res.bodyText);
}

function _yk_md5(s) {
  if (globalThis.Host && Host.crypto && typeof Host.crypto.md5 === "function") {
    return _yk_str(Host.crypto.md5(s));
  }
  return "";
}

// ==================== MTOP 令牌罐（直连兜底用）====================

var _yk_jar = {};

function _yk_cookieHeader() {
  var parts = [];
  for (var k in _yk_jar) {
    if (Object.prototype.hasOwnProperty.call(_yk_jar, k)) parts.push(k + "=" + _yk_jar[k]);
  }
  return parts.join("; ");
}

function _yk_token() {
  var v = _yk_jar["_m_h5_tk"];
  return v ? _yk_str(v).split("_")[0] : "";
}

// 宿主把 Set-Cookie 同时放在 setCookies 与 headers 里，两处都兜住
function _yk_harvest(res) {
  try {
    var sc = "";
    if (res && res.setCookies) {
      sc = Array.isArray(res.setCookies) ? res.setCookies.join("\n") : _yk_str(res.setCookies);
    }
    if (!sc && res && res.headers) {
      var h = res.headers;
      var v = h["Set-Cookie"] || h["set-cookie"] || "";
      sc = Array.isArray(v) ? v.join("\n") : _yk_str(v);
    }
    if (!sc) return;
    var bad = { path: 1, expires: 1, domain: 1, "max-age": 1, secure: 1, httponly: 1, samesite: 1, version: 1, comment: 1 };
    var re = /([A-Za-z0-9_.\-]+)=([^;,\r\n\t ]+)/g;
    var m;
    while ((m = re.exec(sc)) !== null) {
      if (bad[m[1].toLowerCase()]) continue;
      if (m[2].indexOf("GMT") >= 0) continue;
      _yk_jar[m[1]] = m[2];
    }
  } catch (e) { }
}

async function _yk_mtop(api, ver, dataObj) {
  var data = JSON.stringify(dataObj);
  for (var attempt = 0; attempt < 4; attempt++) {
    var t = String(Date.now());
    var tk = _yk_token();
    if (tk && !_yk_md5("probe")) return null;   // 宿主没注入 crypto，直连无法签名
    var sign = tk ? _yk_md5(tk + "&" + t + "&" + _yk_appKey + "&" + data) : "";
    var url = "https://acs.youku.com/h5/" + api + "/" + ver + "/?jsv=2.5.1&appKey=" + _yk_appKey +
      "&t=" + t + "&sign=" + sign + "&api=" + api + "&v=" + ver +
      "&type=originaljson&dataType=json&timeout=20000&data=" + encodeURIComponent(data);
    var res;
    try {
      res = await _yk_request({
        url: url,
        headers: { "Accept": "application/json", "Cookie": _yk_cookieHeader() },
        timeout: 10
      });
    } catch (e) { return null; }
    _yk_harvest(res);
    var j = null;
    try { j = JSON.parse(_yk_body(res)); } catch (e) { }
    if (!j) continue;
    var ret = _yk_str(j.ret && j.ret[0]);
    if (ret.indexOf("TOKEN") >= 0 || ret.indexOf("令牌") >= 0 || ret.indexOf("ILLEGAL_ACCESS") >= 0) {
      if (!_yk_token()) delete _yk_jar["_m_h5_tk"];
      continue;   // 首轮申领令牌、后续轮次用签名重发
    }
    return j;
  }
  return null;
}

// 直连取流：逐个 ckey 试，取最高画质的 h264PlayUrl
async function _yk_directPlay(liveId) {
  for (var i = 0; i < _yk_ckeys.length; i++) {
    var j = await _yk_mtop("mtop.youku.live.com.liveplaycontrol", "4.0", {
      ckey: _yk_ckeys[i],
      encryptRClient: "",
      liveId: String(liveId),
      sceneId: 0,
      reqQuality: 0,
      ad: JSON.stringify({
        site: "youku", aw: "w", p: 1, vs: "1.0", vc: 0, bt: "pc", rst: "mp4", dq: 0,
        isvert: 0, wintype: "h5", bf: 0, utdid: "", fu: 0, os: "win",
        dvh: 384, dvw: 216, ccode: "live05010101", lid: String(liveId)
      }),
      cna: _yk_cna,
      playAbilities: JSON.stringify({ decode_resolution_FPS: "4K_50", abrPlay: 2, vrPlay: 1, mixPlay: 3, mix_ability: 1, decode: "H265" }),
      systemInfo: JSON.stringify({ webPlayerCoreVer: 2 }),
      keyIndex: "web01",
      ccode: "live05010101",
      app: "Pc",
      AntiFlood: true
    });
    var dd = j && j.data && j.data.data;
    if (!dd) continue;
    var qs = (dd.qualities || []).filter(function (q) { return q && q.h264PlayUrl; });
    if (!qs.length) continue;
    qs.sort(function (a, b) { return (Number(b.quality) || 0) - (Number(a.quality) || 0); });
    var u = _yk_str(qs[0].h264PlayUrl);
    if (u.indexOf("http://") === 0) u = "https://" + u.substring(7);
    return /^https?:\/\//.test(u) ? u : "";
  }
  return "";
}

// ==================== 取流 ====================

// 主路径：中转服务（服务端完成令牌 + 签名 + ckey，设备只发一个 GET）
async function _yk_relayPlay(liveId) {
  var url = _yk_relay + "/play/" + String(liveId).replace(/\D/g, "") + _yk_relayQS;
  var res = await _yk_request({ url: url, headers: { "Accept": "application/json" }, timeout: 12 });
  var j = null;
  try { j = JSON.parse(_yk_body(res)); } catch (e) { }
  return j && /^https?:\/\//.test(_yk_str(j.url)) ? j.url : "";
}

async function _yk_resolveURL(liveId) {
  var diag = [];
  try {
    var u = await _yk_relayPlay(liveId);
    if (u) return { url: u, source: "relay", diag: "" };
    diag.push("relay:empty");
  } catch (e) {
    diag.push("relay:" + _yk_str(e && e.message || e).slice(0, 80));
  }
  try {
    var u2 = await _yk_directPlay(liveId);
    if (u2) return { url: u2, source: "mtop", diag: "" };
    diag.push("mtop:no-stream");
  } catch (e) {
    diag.push("mtop:" + _yk_str(e && e.message || e).slice(0, 80));
  }
  _yk_lastPlayFail = diag.join(" | ");
  return { url: "", source: "", diag: _yk_lastPlayFail };
}

// 宿主清晰度对象（qn 越小优先级越高，liveCodeType 决定解封装方式）
function _yk_quality(roomId, url, source) {
  return {
    roomId: roomId,
    title: source === "relay" ? "720P" : "直连",
    qn: 1,
    url: url,
    liveCodeType: "m3u8",
    liveType: _yk_liveType,
    userAgent: _yk_ua,
    requestContext: { kind: "hls", source: source }
  };
}

// ==================== 频道清单 ====================

// 解析 www.youku.com/ku/weblive 的 SSR HTML（实测 441KB / 60 个完整卡片）
async function _yk_channels() {
  if (_yk_channelsLoaded) return _yk_channelCache;
  var html = "";
  try {
    var res = await _yk_request({
      url: _yk_homeURL,
      headers: { "Accept": "text/html,application/xhtml+xml" },
      timeout: 15
    });
    html = _yk_body(res);
  } catch (e) { }
  if (html.length < 5000) {
    try {
      var r2 = await _yk_request({ url: _yk_pageURL, headers: { "Accept": "text/html" }, timeout: 10 });
      var h2 = _yk_body(r2);
      if (h2.length > html.length) html = h2;
    } catch (e) { }
  }
  var out = [], seen = {};
  if (html) {
    var re = /ilproom\?id=(\d{5,10})"[^>]*aria-label="([^"]*)"[\s\S]{0,700}?data-src="([^"]+)"/g;
    var m;
    while ((m = re.exec(html)) !== null) {
      if (seen[m[1]]) continue;
      seen[m[1]] = true;
      var title = _yk_unescape(m[2]).trim();
      if (!title) continue;
      out.push({ id: m[1], name: title, pic: _yk_str(m[3]).split("?")[0] });
    }
  }
  if (out.length) {
    _yk_channelCache = out;
    _yk_channelsLoaded = true;   // 失败不置位，下次进页面自动重试
  }
  return out;
}

// 房间 DTO：字段严格对齐宿主 PluginRoomDTO.swift
function _yk_room(id, name, pic, state) {
  return {
    userName: "优酷直播",
    roomTitle: name || ("直播间 " + id),
    roomCover: pic || "",
    userHeadImg: "",
    liveState: state || "1",
    userId: String(id),
    roomId: String(id),
    liveWatchedCount: ""
  };
}

function _yk_classicRooms() {
  return _yk_classic.map(function (r) { return _yk_room(r[0], r[1], r[2], "1"); });
}

// 详情 / 搜索 / 分享共用：先查白名单，再查 SSR 缓存，最后给最小卡片
async function _yk_detail(liveId) {
  for (var i = 0; i < _yk_classic.length; i++) {
    if (_yk_classic[i][0] === liveId) return _yk_room(liveId, _yk_classic[i][1], _yk_classic[i][2], "1");
  }
  var chs = await _yk_channels();
  for (var j = 0; j < chs.length; j++) {
    if (chs[j].id === liveId) return _yk_room(liveId, chs[j].name, chs[j].pic, "1");
  }
  return _yk_room(liveId, "", "", "1");
}

// ==================== Angel Live 导出接口 ====================

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  async clearCredential() {
    _yk_jar = {};
    return {};
  },

  // 一级「推荐」+ 二级「经典直播 / 全部频道」，与 App 的 tab 层级一致
  async getCategories() {
    return [{
      id: "youku",
      title: "推荐",
      icon: "",
      biz: "youku",
      subList: [
        { id: "classic", parentId: "youku", title: "经典直播", icon: "", biz: "classic" },
        { id: "all", parentId: "youku", title: "全部频道", icon: "", biz: "all" }
      ]
    }];
  },

  // 默认（含父级 id / 未传参）走零网络依赖的经典白名单，绝不白屏；
  // 选中「全部频道」才拉 SSR 全量，SSR 失败自动回退白名单。
  async getRooms(payload) {
    var p = payload || {};
    var page = Math.max(1, Number(p.page) || 1);
    if (page > 1) return [];
    var cat = _yk_str(p.childId || p.id || p.categoryId || p.parentBiz || p.biz || "").trim();
    if (/all/i.test(cat)) {
      var chs = await _yk_channels();
      if (chs.length) {
        return chs.map(function (c) { return _yk_room(c.id, c.name, c.pic, "1"); });
      }
    }
    return _yk_classicRooms();
  },

  async getRoomDetail(payload) {
    return await _yk_detail(_yk_requireId(payload));
  },

  // 24 小时轮播频道，未开播的接口状态无法在设备端可靠判定，统一视为在播；
  // 实际能否播放交给 getPlayback 的取流结果判定。
  async getLiveState(payload) {
    var id = _yk_requireId(payload);
    return { liveState: "1", roomId: id };
  },

  async getPlayback(payload) {
    var id = _yk_requireId(payload);
    var r = await _yk_resolveURL(id);
    if (!r.url) {
      _yk_throw("NOT_LIVE", "youku returned no playable stream", { roomId: id, diag: r.diag });
    }
    return [{
      cdn: _yk_platformId,
      displayName: r.source === "relay" ? "优酷·720P" : "优酷·直连",
      requestContext: { roomId: id, kind: "hls" },
      qualitys: [_yk_quality(id, r.url, r.source)]
    }];
  },

  // 注意：宿主约定 refreshPlayback 返回「单个清晰度对象」，不是线路数组。
  // m3u8 带 ykLiveSign（约 6 小时失效），刷新时重新向中转要一条新流。
  async refreshPlayback(payload) {
    var p = payload || {};
    var id = _yk_extractId(p.roomId || (p.quality && p.quality.roomId));
    if (!id) _yk_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    var r = await _yk_resolveURL(id);
    if (!r.url) {
      _yk_throw("NOT_LIVE", "youku returned no playable stream", { roomId: id, diag: r.diag });
    }
    return _yk_quality(id, r.url, r.source);
  },

  // 支持：纯数字 liveId、直播间链接、以及频道名关键词
  async search(payload) {
    var kw = _yk_str(payload && payload.keyword).trim();
    if (!kw) return [];
    var id = _yk_extractId(kw);
    if (id) return [await _yk_detail(id)];
    var chs = await _yk_channels();
    var out = [];
    for (var i = 0; i < chs.length && out.length < 30; i++) {
      if (chs[i].name.indexOf(kw) >= 0) out.push(_yk_room(chs[i].id, chs[i].name, chs[i].pic, "1"));
    }
    return out;
  },

  // 分享内容里的 vku.youku.com/live/ilproom?id=<liveId>
  async resolveShare(payload) {
    var shareCode = _yk_str(payload && payload.shareCode).trim();
    if (!shareCode) _yk_throw("INVALID_ARGS", "shareCode is required", { field: "shareCode" });
    var id = _yk_extractId(shareCode);
    if (!id) _yk_throw("NOT_FOUND", "liveId was not found in the share content", { shareCode: shareCode });
    return await _yk_detail(id);
  }
};
