// Angel Live 插件：优酷直播骨架 v1.0.0
// 目标站点：https://live.youku.com
//
// 抓包后只需要填下面三处 TODO，本文件其它部分不用改：
//   TODO(1) _yk_listURL  —— 首页/分类的房间列表接口
//   TODO(2) _yk_playURL  —— 进房取流接口（返回 m3u8 或 flv 地址）
//   TODO(3) _yk_parseRooms / _yk_parsePlayback —— 按真实响应字段做映射
//
// 抓包定位路径（Charles / Fiddler / 浏览器 DevTools）：
//   1. 打开 https://live.youku.com，筛选 XHR/Fetch，找返回直播间数组的请求
//   2. 点进一个直播间，找返回 m3u8 / flv / 流地址的请求
//   3. 注意记录：完整 URL、Query 参数、Cookie（utid / token 等）、
//      Referer、User-Agent、以及任何签名参数（sign / token / _t）
//   4. 把 curl 原样贴给我，我把 TODO 填成可播放的实现

const _yk_platformId = "youku";
const _yk_liveType = "0";
const _yk_ua = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36";
const _yk_referer = "https://live.youku.com/";

// TODO(1) 房间列表接口，例：https://live.youku.com/xxx?...
const _yk_listURL = "";
// TODO(2) 取流接口，例：https://live.youku.com/xxx?roomId=...
const _yk_playURL = "";

function _yk_str(value) {
  return value === undefined || value === null ? "" : String(value);
}

function _yk_throw(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") {
    Host.raise(code, message, context || {});
  }
  if (globalThis.Host && typeof Host.makeError === "function") {
    throw Host.makeError(code || "UNKNOWN", message || "", context || {});
  }
  throw new Error("LP_PLUGIN_ERROR:" + JSON.stringify({
    code: String(code || "UNKNOWN"),
    message: String(message || ""),
    context: context || {}
  }));
}

// 宿主注入的原生网络接口：Host.http.request({ url, method, headers, timeout })
// 响应字段：status / statusCode、bodyText
async function _yk_request(options) {
  if (!globalThis.Host || !Host.http || typeof Host.http.request !== "function") {
    _yk_throw("UNSUPPORTED", "Host.http.request is unavailable", {});
  }
  const response = await Host.http.request({
    url: options.url,
    method: options.method || "GET",
    headers: Object.assign({
      "User-Agent": _yk_ua,
      "Referer": _yk_referer,
      "Accept": "application/json, text/plain, */*"
    }, options.headers || {}),
    timeout: options.timeout || 20
  });
  const status = Number(response && (response.status || response.statusCode)) || 0;
  if (status >= 400) {
    _yk_throw("UPSTREAM", "youku HTTP " + status, { url: options.url });
  }
  return _yk_str(response && response.bodyText);
}

async function _yk_getJSON(url, headers) {
  const text = await _yk_request({ url, headers });
  try {
    return JSON.parse(text);
  } catch (error) {
    // 上游若返回 JSONP，去掉回调外壳再解一次
    const start = text.indexOf("(");
    const end = text.lastIndexOf(")");
    if (start > 0 && end > start) {
      try { return JSON.parse(text.slice(start + 1, end)); } catch (ignored) {}
    }
    _yk_throw("PARSE", "youku response is not JSON", { preview: text.slice(0, 120) });
  }
}

// TODO(3a) 把抓包得到的列表项映射成宿主房间对象（字段名已对齐宿主 DTO）：
//   { userName, roomTitle, roomCover, userHeadImg, liveType,
//     liveState, userId, roomId, liveWatchedCount }
function _yk_parseRooms(payload) {
  void payload;
  return [];
}

// TODO(3b) 把取流响应映射成宿主清晰度对象：
//   { roomId, title, qn, url, liveCodeType: "m3u8" 或 "flv",
//     liveType, userAgent, requestContext: { kind: "hls" } }
function _yk_parsePlayback(roomId, payload) {
  void roomId;
  void payload;
  return [];
}

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  // 静态分类：抓包前也能在 App 里看到平台入口
  async getCategories() {
    return [{
      id: "recommend",
      title: "推荐",
      icon: "",
      biz: "recommend",
      subList: [{ id: "recommend", parentId: "recommend", title: "全部", icon: "", biz: "recommend" }]
    }];
  },

  async getRooms(payload) {
    if (!_yk_listURL) return [];
    const page = Math.max(1, Number(payload && payload.page) || 1);
    const url = _yk_listURL + ( _yk_listURL.indexOf("?") >= 0 ? "&" : "?" ) + "page=" + page;
    return _yk_parseRooms(await _yk_getJSON(url));
  },

  async getRoomDetail(payload) {
    const roomId = _yk_str(payload && payload.roomId);
    if (!roomId) _yk_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return { roomId, userName: "", roomTitle: "", roomCover: "", liveType: _yk_liveType, liveState: "0" };
  },

  async getLiveState(payload) {
    const roomId = _yk_str(payload && payload.roomId);
    if (!roomId) _yk_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return { liveState: "0" };
  },

  async getPlayback(payload) {
    const roomId = _yk_str(payload && payload.roomId);
    if (!roomId) _yk_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    if (!_yk_playURL) {
      _yk_throw("UNSUPPORTED", "请先抓包填入 _yk_playURL 与 _yk_parsePlayback", { roomId });
    }
    const qualitys = _yk_parsePlayback(roomId, await _yk_getJSON(_yk_playURL + roomId));
    if (!qualitys.length) _yk_throw("NOT_LIVE", "youku returned no playable stream", { roomId });
    return [{
      cdn: _yk_platformId,
      displayName: "默认线路",
      requestContext: { roomId },
      qualitys
    }];
  },

  async refreshPlayback(payload) {
    return await this.getPlayback(payload);
  },

  async search(payload) {
    return [];
  },

  async resolveShare(payload) {
    const shareCode = _yk_str(payload && payload.shareCode).trim();
    if (!shareCode) _yk_throw("INVALID_ARGS", "shareCode is required", { field: "shareCode" });
    _yk_throw("UNSUPPORTED", "分享链接解析待抓包填充", { shareCode });
  }
};
