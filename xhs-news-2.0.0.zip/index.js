// Angel Live 插件：官媒直播 v2.0.0 —— 官网固定源（B 方案）
//
// ── 为什么要做这一版 ──────────────────────────────────────────────
// 小红书每次开播都会换房间号，而且没有免签名的「主播 ID → 当前房号」接口
// （主播主页 SSR、搜索 onebox、直播广场 SSR 都是空壳，otherinfo /
//  squarefeed / current_room_info 一律 406 需 x-s 签名），宿主也没给插件
// 任何本地持久化存储。所以 v1.1.0 的「房号池」再怎么优化，本质上仍然
// 需要人工提供一次最新链接。
//
// v2.0.0 走 B 方案：绕开小红书，直接吃官媒自己的官网固定直播信号。
// 频道号是固定的（cctv1 / cctv13 ...），永远不存在「房号会变」。
//
// ── 官网取流（2026-11-28 实测可用，零登录 / 零 Cookie / 零签名）──────
//   GET https://vdn.live.cntv.cn/api2/liveHtml5.do
//       ?channel=pw://cctv_p2p_hd<频道>&channel_id=<频道>
//       &video_player=1&client=html5
//   返回 JS 文本：var html5VideoData = '{...}';getHtml5VideoData(...);
//   JSON 里 hls_url.hls1 = 720P master m3u8，hls2 = 576P master m3u8
//   实测 CCTV1/2/3/4/6/7/10/11/12/13/15/17 的 m3u8 均 200、无 EXT-X-KEY。
//   注意：播放器脚本里的 vc / tsp / uid 签名参数实测全部可省略，
//   乱填 vc 或不带 Referer 都返回 ack=yes，因此本插件不做任何签名计算。
//
//   GET https://api.cntv.cn/epg/nowepg?c=<频道>&serviceId=tvcctv
//   返回官网当前节目单 {t: 节目名, n: 频道名, e: 结束时间}，用作实时标题。
//
// ── 关于另外 5 家官媒 ─────────────────────────────────────────────
// 新华网 / 参考消息 / 央视频 / 学习强国 / 快看 的官网直播页都是活动型
// 临时房间（新华网云直播 roomId、央视频 SPA），没有 24 小时固定 m3u8；
// 它们的直播信号本身也多为央视信号。实测：
//   · 新华网 CNC 固定流 source07.v.news.cn/live/CNC_CN/playlist.m3u8 → 404
//   · live.v.news.cn 云直播页 → 503 / CANNOT FORWARD
//   · 央视频 yangshipin.cn/tv/home、学习强国 xuexi.cn → SPA 空壳，无 m3u8
// 因此官网固定源实际可用的只有央视系频道。本版把 6 个官媒名映射到
// 对应的央视官方频道（每个官媒给 2 条线路可切），并如实写在房间标题里，
// 不做「这就是该账号原播」的虚假承诺。想看小红书原播内容，切到
// 「小红书原播」分类即可（仍用 v1.1.0 的房号池，需要最新链接）。
//
// 本插件不声明 auth、不读取任何凭证、不上传任何 Cookie / x-s 签名。

var _xn_platformId = "xhs-news";
var _xn_liveType = "11";
var _xn_ua = "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1";
var _xn_referer = "https://app.xhs.cn/";
var _xn_base = "https://www.xiaohongshu.com/livestream/";
var _xn_roomsURLs = [
  "https://cdn.jsdelivr.net/gh/gaoshangshuai/angel-plugins@main/rooms.json",
  "https://gcore.jsdelivr.net/gh/gaoshangshuai/angel-plugins@main/rooms.json",
  "https://raw.githubusercontent.com/gaoshangshuai/angel-plugins/refs/heads/main/rooms.json"
];
var _xn_remoteTTL = 300000;
var _xn_maxCandidates = 8;

// ==================== 官网固定源：频道表 ====================

var _gm_ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
var _gm_referer = "https://tv.cctv.com/live/";
var _gm_vdnBase = "https://vdn.live.cntv.cn/api2/liveHtml5.do";
var _gm_epgBase = "https://api.cntv.cn/epg/nowepg";

// 6 个官媒 → 央视官方固定频道（主线路 + 备用线路）。
// 每条线路在播放器里是一组「清晰度」，用户可自由切换。
var _gm_official = [
  { id: "gm_cctv",    name: "央视网",   aliases: ["央视网", "CCTV", "央视"], lines: ["cctv1", "cctv13"] },
  { id: "gm_kuaikan", name: "快看",     aliases: ["快看"],                   lines: ["cctv3", "cctv6"] },
  { id: "gm_ckxx",    name: "参考消息", aliases: ["参考消息"],               lines: ["cctv4", "cctv2"] },
  { id: "gm_ysp",     name: "央视频",   aliases: ["央视频"],                 lines: ["cctv13", "cctv1"] },
  { id: "gm_xhw",     name: "新华网",   aliases: ["新华网", "新华社"],        lines: ["cctv4", "cctv13"] },
  { id: "gm_xxqg",    name: "学习强国", aliases: ["学习强国"],               lines: ["cctv1", "cctv10"] }
];

// 央视全频道（只列实测能稳定拿到 HLS 的 12 个；cctv5/8/9/14/16 官网
// 当前不下发直连流，列出来只会点了报错，故不进列表）。
var _gm_cctvChannels = [
  { ch: "cctv1",  name: "CCTV-1 综合" },
  { ch: "cctv2",  name: "CCTV-2 财经" },
  { ch: "cctv3",  name: "CCTV-3 综艺" },
  { ch: "cctv4",  name: "CCTV-4 中文国际" },
  { ch: "cctv6",  name: "CCTV-6 电影" },
  { ch: "cctv7",  name: "CCTV-7 国防军事" },
  { ch: "cctv10", name: "CCTV-10 科教" },
  { ch: "cctv11", name: "CCTV-11 戏曲" },
  { ch: "cctv12", name: "CCTV-12 社会与法" },
  { ch: "cctv13", name: "CCTV-13 新闻" },
  { ch: "cctv15", name: "CCTV-15 音乐" },
  { ch: "cctv17", name: "CCTV-17 农业农村" }
];

var _gm_vdnCache = {};   // ch -> {streams, cdn, ts}
var _gm_epgCache = {};   // ch -> {title, name, ts}

// ==================== 小红书原播：频道表（v1.1.0 房号池）====================

var _xn_channels = [
  { id: "cctv",    name: "央视网",   aliases: ["央视网", "CCTV", "央视"],  hostId: "6470182e000000002a03454a", candidates: ["570559521790467377"], roomId: "570559521790467377", learned: false, stale: false },
  { id: "kuaikan", name: "快看",     aliases: ["快看"],                    hostId: "", candidates: [], roomId: "", learned: false, stale: false },
  { id: "ckxx",    name: "参考消息", aliases: ["参考消息"],                hostId: "", candidates: [], roomId: "", learned: false, stale: false },
  { id: "ysp",     name: "央视频",   aliases: ["央视频"],                  hostId: "", candidates: [], roomId: "", learned: false, stale: false },
  { id: "xhw",     name: "新华网",   aliases: ["新华网", "新华社"],        hostId: "", candidates: [], roomId: "", learned: false, stale: false },
  { id: "xxqg",    name: "学习强国", aliases: ["学习强国"],                hostId: "", candidates: [], roomId: "", learned: false, stale: false }
];

var _xn_roomCache = {};
var _xn_remoteTs = 0;
var _xn_lastErr = "";

// ==================== 基础工具 ====================

function _xn_str(v) {
  return v === undefined || v === null ? "" : String(v);
}

function _xn_throw(code, message, context) {
  var ctx = context || {};
  if (globalThis.Host && typeof Host.raise === "function") Host.raise(code, message, ctx);
  if (globalThis.Host && typeof Host.makeError === "function") {
    throw Host.makeError(code || "UNKNOWN", message || "", ctx);
  }
  throw new Error("LP_PLUGIN_ERROR:" + JSON.stringify({
    code: String(code || "UNKNOWN"), message: String(message || ""), context: ctx
  }));
}

function _xn_extractRoomId(text) {
  var t = _xn_str(text);
  if (!t) return "";
  var pats = [
    /livestream\/([0-9]{10,24})/i,
    /livestream\/[^/?#\s]+\/([0-9]{10,24})/i,
    /room_id[=:]([0-9]{10,24})/i,
    /\/live\/([0-9]{10,24})\.(?:flv|m3u8)/i,
    /(?:\D|^)([0-9]{15,20})(?:\D|$)/,
    /^([0-9]{10,24})$/
  ];
  for (var i = 0; i < pats.length; i++) {
    var m = pats[i].exec(t);
    if (m && m[1]) return m[1];
  }
  return "";
}

function _xn_channelById(id) {
  for (var i = 0; i < _xn_channels.length; i++) {
    if (_xn_channels[i].id === id) return _xn_channels[i];
  }
  return null;
}

function _xn_channelByRoomId(roomId) {
  for (var i = 0; i < _xn_channels.length; i++) {
    var ch = _xn_channels[i];
    if (ch.roomId && ch.roomId === roomId) return ch;
    for (var j = 0; j < ch.candidates.length; j++) {
      if (ch.candidates[j] === roomId) return ch;
    }
  }
  return null;
}

function _xn_requireRoom(payload) {
  var p = payload || {};
  var raw = _xn_str(p.roomId || p.url || p.shareCode || (p.quality && p.quality.roomId) || "");
  var id = _xn_extractRoomId(raw);
  if (id) return id;
  var cid = _xn_str(p.roomId || p.id || "").trim();
  var ch = _xn_channelById(cid);
  if (ch && !ch.roomId) {
    _xn_throw("NOT_FOUND",
      "「" + ch.name + "」还没绑定小红书直播间。小红书每次开播房号会变；建议改用「官媒直通 · 官网固定源」分类，频道号固定、不用维护。",
      { channel: ch.id });
  }
  if (ch && ch.stale) {
    _xn_throw("NOT_FOUND",
      "「" + ch.name + "」的小红书房号已失效。建议改用「官媒直通 · 官网固定源」分类。",
      { channel: ch.id, staleRoomId: ch.roomId });
  }
  _xn_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
  return "";
}

// ==================== 宿主网络层 ====================

// Host.http.request({url,method,headers,timeout}) → {status,headers,bodyText}
// opts 可覆盖 ua / referer / accept，官网接口用桌面 UA。
async function _xn_request(url, timeout, opts) {
  if (!globalThis.Host || !Host.http || typeof Host.http.request !== "function") {
    _xn_throw("UNSUPPORTED", "Host.http.request is unavailable", {});
  }
  var o = opts || {};
  var raw = await Host.http.request({
    url: url,
    method: "GET",
    headers: {
      "User-Agent": o.ua || _xn_ua,
      "Referer": o.referer || _xn_referer,
      "Accept": o.accept || "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
      "Accept-Language": "zh-CN,zh;q=0.9",
      "Cache-Control": "no-cache"
    },
    timeout: timeout || 15
  });
  var res = raw;
  if (typeof raw === "string") {
    try { res = JSON.parse(raw); } catch (e) { res = { bodyText: raw }; }
  }
  return res || {};
}

async function _gm_request(url, timeout) {
  return _xn_request(url, timeout, { ua: _gm_ua, referer: _gm_referer, accept: "*/*" });
}

// ==================== 官网固定源：取流 / 节目单 ====================

function _gm_known(ch) {
  for (var i = 0; i < _gm_cctvChannels.length; i++) {
    if (_gm_cctvChannels[i].ch === ch) return true;
  }
  return false;
}

function _gm_channelName(ch) {
  for (var i = 0; i < _gm_cctvChannels.length; i++) {
    if (_gm_cctvChannels[i].ch === ch) return _gm_cctvChannels[i].name;
  }
  return String(ch).toUpperCase();
}

function _gm_vdnURL(ch) {
  return _gm_vdnBase + "?channel=pw://cctv_p2p_hd" + ch + "&channel_id=" + ch +
    "&video_player=1&client=html5";
}

// 返回 {streams:[{url,label,line}], cdn, play}；服务端不下发流时返回 null。
async function _gm_fetchVDN(ch, force) {
  var now = Date.now();
  var hit = _gm_vdnCache[ch];
  if (!force && hit && now - hit.ts < 60000) return hit;

  var res = await _gm_request(_gm_vdnURL(ch), 12);
  var txt = _xn_str(res && res.bodyText);
  var m = /html5VideoData\s*=\s*'([\s\S]*?)'\s*;/.exec(txt);
  if (!m) { _xn_lastErr = "VDN: html5VideoData not found"; return null; }

  var d;
  try { d = JSON.parse(m[1]); } catch (e) { _xn_lastErr = "VDN: JSON parse failed"; return null; }
  if (!d || d.ack !== "yes") {
    _xn_lastErr = "VDN: ack=" + _xn_str(d && d.ack) + " tip=" + _xn_str(d && d.tip_msg);
    return null;
  }

  var h = d.hls_url || {};
  var streams = [];
  if (/^https?:\/\//i.test(_xn_str(h.hls1))) {
    streams.push({ url: _xn_str(h.hls1), label: "高清 720P", line: "hls1" });
  }
  if (/^https?:\/\//i.test(_xn_str(h.hls2)) && h.hls2 !== h.hls1) {
    streams.push({ url: _xn_str(h.hls2), label: "标清 576P", line: "hls2" });
  }
  if (!streams.length) {
    _xn_lastErr = "VDN: 官网当前未下发该频道直连流（版权 / 区域限制）";
    return null;
  }

  var info = {
    streams: streams,
    cdn: _xn_str((d.hls_cdn_info || {}).cdn_code) || "CCTV-HLS",
    play: _xn_str(d.play),
    ts: now
  };
  _gm_vdnCache[ch] = info;
  return info;
}

async function _gm_fetchEPG(ch) {
  var now = Date.now();
  var hit = _gm_epgCache[ch];
  if (hit && now - hit.ts < 120000) return hit;

  var res = await _gm_request(_gm_epgBase + "?c=" + encodeURIComponent(ch) + "&serviceId=tvcctv", 8);
  var txt = _xn_str(res && res.bodyText).trim();
  var out = { title: "", name: _gm_channelName(ch), end: "", ts: now };
  try {
    var d = JSON.parse(txt);
    if (Array.isArray(d)) d = d[0] || {};
    if (d && typeof d === "object") {
      out.title = _xn_str(d.t);
      out.name = _xn_str(d.n) || out.name;
      out.end = _xn_str(d.e);
    }
  } catch (e) { /* 节目单不可用不影响播放 */ }
  _gm_epgCache[ch] = out;
  return out;
}

// roomId → 官网源描述对象
function _gm_find(roomId) {
  var id = _xn_str(roomId);
  for (var i = 0; i < _gm_official.length; i++) {
    if (_gm_official[i].id === id) return _gm_official[i];
  }
  var m = /^tv_(cctv\d+)$/i.exec(id);
  if (m) {
    var ch = m[1].toLowerCase();
    return { id: id, name: _gm_channelName(ch), aliases: [ch, _gm_channelName(ch)], lines: [ch] };
  }
  // 也接受直接传频道号（cctv1 / CCTV13）
  if (/^cctv\d+$/i.test(id)) {
    var c = id.toLowerCase();
    return { id: "tv_" + c, name: _gm_channelName(c), aliases: [c], lines: [c] };
  }
  return null;
}

function _gm_isOfficial(roomId) {
  return !!_gm_find(roomId);
}

function _gm_roomDTO(meta, epg) {
  var ch = meta.lines[0];
  var chName = _gm_channelName(ch);
  var program = epg && epg.title ? epg.title : "正在直播";
  var extra = meta.lines.length > 1 ? "（可切 " + meta.lines.length + " 路官网信号）" : "";
  return {
    userName: meta.name,
    roomTitle: chName + " · " + program + " · 官网固定源" + extra,
    roomCover: "",
    userHeadImg: "",
    liveState: "1",
    userId: meta.id,
    roomId: meta.id,
    liveWatchedCount: ""
  };
}

function _gm_quality(roomId, url, title, qn, ch, line, cdn) {
  return {
    roomId: String(roomId),
    title: title,
    qn: qn,
    url: url,
    liveCodeType: "m3u8",
    liveType: _xn_liveType,
    userAgent: _gm_ua,
    requestContext: {
      kind: "hls", source: "cctv_vdn", ch: ch, line: line,
      cdn: cdn, roomId: String(roomId)
    }
  };
}

async function _gm_rooms(list) {
  var epgs = await Promise.all(list.map(function (o) {
    return _gm_fetchEPG(o.lines[0]).catch(function () { return null; });
  }));
  var out = [];
  for (var i = 0; i < list.length; i++) out.push(_gm_roomDTO(list[i], epgs[i]));
  return out;
}

async function _gm_playbackLines(roomId) {
  var meta = _gm_find(roomId);
  if (!meta) return null;

  var vdns = await Promise.all(meta.lines.map(function (ch) {
    return _gm_fetchVDN(ch, true).catch(function () { return null; });
  }));

  var lines = [];
  for (var i = 0; i < meta.lines.length; i++) {
    var v = vdns[i];
    if (!v || !v.streams.length) continue;
    var ch = meta.lines[i];
    var qs = [];
    for (var j = 0; j < v.streams.length; j++) {
      var s = v.streams[j];
      qs.push(_gm_quality(roomId, s.url, s.label, j + 1, ch, s.line, v.cdn));
    }
    lines.push({
      cdn: v.cdn,
      displayName: _gm_channelName(ch) + " · 官网 HLS",
      requestContext: { roomId: String(roomId), kind: "hls", source: "cctv_vdn", ch: ch },
      qualitys: qs
    });
  }
  if (!lines.length) {
    _xn_throw("NOT_LIVE",
      "该频道官网当前未下发直连流（可能是版权或区域限制）。可切到「央视全频道」选其它频道，或到「小红书原播」粘贴直播链接。",
      { roomId: roomId, diag: _xn_lastErr });
  }
  return lines;
}

// ==================== 小红书原播：SSR 解析 / 房号池 ====================

function _xn_extractObj(text, key) {
  var k = '"' + key + '"';
  var i = text.indexOf(k);
  if (i < 0) return null;
  var start = text.indexOf("{", i + k.length);
  if (start < 0) return null;
  var depth = 0, inStr = false, esc = false;
  for (var j = start; j < text.length; j++) {
    var ch = text.charAt(j);
    if (inStr) {
      if (esc) esc = false;
      else if (ch === "\\") esc = true;
      else if (ch === '"') inStr = false;
    } else {
      if (ch === '"') inStr = true;
      else if (ch === "{") depth++;
      else if (ch === "}") {
        depth--;
        if (depth === 0) return text.slice(start, j + 1);
      }
    }
  }
  return null;
}

function _xn_parseLive(html) {
  var objText = _xn_extractObj(html, "liveStream");
  if (!objText) return null;
  try {
    return JSON.parse(objText.replace(/\bundefined\b/g, "null"));
  } catch (e) {
    return null;
  }
}

function _xn_isHLS(url) {
  return /\.m3u8(?:[?#]|$)/i.test(_xn_str(url));
}

function _xn_streams(live) {
  var rd = live && live.roomData;
  var ri = rd && rd.roomInfo;
  var out = [];
  if (!ri) return out;
  var pc = null;
  try {
    if (typeof ri.pullConfig === "string") pc = JSON.parse(ri.pullConfig);
    else if (ri.pullConfig && typeof ri.pullConfig === "object") pc = ri.pullConfig;
  } catch (e) { pc = null; }
  if (pc && pc.h264 && pc.h264.length) {
    for (var i = 0; i < pc.h264.length; i++) {
      var u = _xn_str(pc.h264[i] && pc.h264[i].master_url);
      if (u) out.push({ url: u, label: _xn_str(pc.h264[i].quality_type_name) || "原画" });
    }
  }
  if (!out.length) {
    var m = /flvUrl=([^&]+)/.exec(_xn_str(ri.deeplink));
    if (m) {
      try { out.push({ url: decodeURIComponent(m[1]), label: "原画" }); } catch (e) { }
    }
  }
  return out;
}

async function _xn_fetchRoom(roomId, force) {
  var now = Date.now();
  var cached = _xn_roomCache[roomId];
  if (!force && cached && now - cached.ts < 30000) return cached;

  var url = _xn_base + encodeURIComponent(roomId) + "?source=web_live_list";
  var res = await _xn_request(url, 15);
  var html = _xn_str(res && res.bodyText);
  if (!html) { _xn_lastErr = "empty response"; return null; }
  var live = _xn_parseLive(html);
  if (!live) { _xn_lastErr = "liveStream not found in SSR"; return null; }

  var rd = live.roomData || {};
  var ri = rd.roomInfo || {};
  var hi = rd.hostInfo || {};
  var status = Number(ri.status || 0);
  var info = {
    roomId: _xn_str(ri.roomId) || roomId,
    title: _xn_str(ri.roomTitle),
    cover: _xn_str(ri.roomCover),
    host: _xn_str(hi.nickName),
    avatar: _xn_str(hi.avatar),
    viewers: _xn_str(ri.displayViewerCount),
    status: status,
    liveState: status === 2 ? "1" : "0",
    pageStatus: _xn_str(live.pageStatus),
    error: _xn_str(live.errorMessage),
    streams: _xn_streams(live),
    ts: now
  };
  _xn_roomCache[roomId] = info;
  _xn_learn(info);
  return info;
}

function _xn_usable(info) {
  return !!(info && info.liveState === "1" && info.streams && info.streams.length);
}

function _xn_pushCandidate(ch, value, front) {
  var id = _xn_extractRoomId(value);
  if (!id) return false;
  var arr = ch.candidates;
  for (var i = 0; i < arr.length; i++) {
    if (arr[i] === id) {
      if (front && i > 0) { arr.splice(i, 1); arr.unshift(id); }
      return false;
    }
  }
  if (front) arr.unshift(id); else arr.push(id);
  if (arr.length > _xn_maxCandidates) arr.length = _xn_maxCandidates;
  return true;
}

function _xn_learn(info) {
  if (!_xn_usable(info) || !info.host || !info.roomId) return null;
  var h = info.host;
  for (var i = 0; i < _xn_channels.length; i++) {
    var ch = _xn_channels[i];
    for (var k = 0; k < ch.aliases.length; k++) {
      var a = ch.aliases[k];
      if (h.indexOf(a) >= 0 || (a.length > 1 && a.indexOf(h) >= 0)) {
        var changed = ch.roomId !== info.roomId;
        _xn_pushCandidate(ch, info.roomId, true);
        ch.roomId = info.roomId;
        if (changed) ch.learned = true;
        ch.stale = false;
        return ch;
      }
    }
  }
  return null;
}

function _xn_parseChannelValue(v) {
  var ids = [];
  function add(x) {
    if (x === undefined || x === null || typeof x === "object") return;
    var id = _xn_extractRoomId(_xn_str(x));
    if (id && ids.indexOf(id) < 0) ids.push(id);
  }
  if (Array.isArray(v)) {
    for (var i = 0; i < v.length; i++) add(v[i]);
  } else if (v && typeof v === "object") {
    var keys = ["roomId", "room_id", "url", "link", "pinned"];
    for (var k = 0; k < keys.length; k++) add(v[keys[k]]);
    var lists = ["roomIds", "rooms", "candidates", "history"];
    for (var m = 0; m < lists.length; m++) {
      var arr = v[lists[m]];
      if (Array.isArray(arr)) for (var n = 0; n < arr.length; n++) add(arr[n]);
    }
  } else {
    add(v);
  }
  return ids;
}

async function _xn_loadRemote(force) {
  var now = Date.now();
  if (!force && _xn_remoteTs && now - _xn_remoteTs < _xn_remoteTTL) return;
  _xn_remoteTs = now;
  var data = null;
  for (var u = 0; u < _xn_roomsURLs.length && !data; u++) {
    try {
      var res = await _xn_request(_xn_roomsURLs[u], 8);
      var txt = _xn_str(res && res.bodyText).trim();
      if (txt.charAt(0) !== "{") continue;
      data = JSON.parse(txt);
    } catch (e) { /* 换下一个镜像 */ }
  }
  if (!data) return;
  var map = data.channels || data.rooms || {};
  var hosts = data.hosts || {};
  for (var i = 0; i < _xn_channels.length; i++) {
    var ch = _xn_channels[i];
    if (hosts[ch.id]) ch.hostId = _xn_str(hosts[ch.id]);
    if (!(ch.id in map)) continue;
    var ids = _xn_parseChannelValue(map[ch.id]);
    if (!ids.length) continue;
    for (var j = 0; j < ids.length; j++) _xn_pushCandidate(ch, ids[j], false);
    if (ch.learned) continue;
    if (ch.stale || !ch.roomId || ids.indexOf(ch.roomId) < 0) {
      ch.roomId = ids[0];
      ch.stale = false;
      delete _xn_roomCache[ch.roomId];
    }
  }
}

async function _xn_resolveChannel(ch) {
  var ids = [];
  if (ch.roomId) ids.push(ch.roomId);
  for (var i = 0; i < ch.candidates.length; i++) {
    if (ids.indexOf(ch.candidates[i]) < 0) ids.push(ch.candidates[i]);
  }
  if (!ids.length) return null;
  for (var k = 0; k < ids.length; k++) {
    var info = null;
    try { info = await _xn_fetchRoom(ids[k], k > 0); } catch (e) { info = null; }
    if (_xn_usable(info)) {
      if (ch.roomId !== ids[k]) ch.learned = true;
      ch.roomId = ids[k];
      ch.stale = false;
      return info;
    }
  }
  ch.stale = !!ch.roomId || ch.candidates.length > 0;
  return null;
}

function _xn_roomDTO(ch, info) {
  var bound = !!(ch && ch.roomId);
  var title = info && info.title ? info.title : (ch ? ch.name : "小红书直播");
  if (!bound) {
    title = (ch ? ch.name : "小红书直播") + " · 待绑定直播间（建议改用官网固定源分类）";
  } else if (!info || ch.stale) {
    title = (ch ? ch.name : "小红书直播") + " · 房号已失效，请粘贴最新直播链接";
  } else if (ch.learned) {
    title = title + " · 新房号已记住（" + ch.roomId + "，填进 rooms.json 可长期生效）";
  }
  return {
    userName: (info && info.host) || (ch ? ch.name : "小红书直播"),
    roomTitle: title,
    roomCover: (info && info.cover) || "",
    userHeadImg: (info && info.avatar) || "",
    liveState: bound ? ((info && info.liveState) || "1") : "1",
    userId: ch ? ch.id : "",
    roomId: String(bound ? ch.roomId : (ch ? ch.id : "")),
    liveWatchedCount: (info && info.viewers) || ""
  };
}

function _xn_quality(roomId, url, type, title, qn, line) {
  return {
    roomId: String(roomId),
    title: title,
    qn: qn,
    url: url,
    liveCodeType: type,
    liveType: _xn_liveType,
    userAgent: _xn_ua,
    requestContext: { kind: type, source: "xhs_ssr", line: line, roomId: String(roomId) }
  };
}

function _xn_playbackLines(info) {
  var id = info.roomId;
  var hls = [], flv = [];
  for (var i = 0; i < info.streams.length; i++) {
    (_xn_isHLS(info.streams[i].url) ? hls : flv).push(info.streams[i]);
  }
  var lines = [];
  if (hls.length) {
    var hq = [];
    for (var a = 0; a < hls.length; a++) {
      hq.push(_xn_quality(id, hls[a].url, "m3u8", (hls[a].label || "原画") + " · HLS", a + 1, "hls"));
    }
    lines.push({
      cdn: "xhscdn",
      displayName: "小红书 · 原画 HLS（推荐）",
      requestContext: { roomId: id, kind: "hls", source: "xhs_ssr", line: "hls" },
      qualitys: hq
    });
  }
  if (flv.length) {
    var fq = [];
    for (var b = 0; b < flv.length; b++) {
      var u = flv[b].url;
      var label = /bak-tx/.test(u) ? "腾讯备线" : (/bak-hw/.test(u) ? "华为备线" : "主线路");
      fq.push(_xn_quality(id, u, "flv", (flv[b].label || "原画") + " · " + label, b + 1, "flv"));
    }
    lines.push({
      cdn: "xhscdn",
      displayName: "小红书 · FLV 备线",
      requestContext: { roomId: id, kind: "flv", source: "xhs_ssr", line: "flv" },
      qualitys: fq
    });
  }
  return lines;
}

// ==================== 分类 / 房间分发 ====================

function _gm_allChannels() {
  var out = [];
  for (var i = 0; i < _gm_cctvChannels.length; i++) {
    var c = _gm_cctvChannels[i];
    out.push({ id: "tv_" + c.ch, name: c.name, aliases: [c.ch, c.name], lines: [c.ch] });
  }
  return out;
}

// 判断 payload 里的 roomId 属于哪条链路：
//   "official" → 官网固定源；"xhs" → 小红书原播
function _xn_kind(payload) {
  var p = payload || {};
  var q = p.quality || {};
  var ctx = q.requestContext || {};
  if (ctx.source === "cctv_vdn") return "official";
  if (ctx.source === "xhs_ssr") return "xhs";
  var id = _xn_str(p.roomId || p.id || q.roomId || ctx.roomId || p.url || p.shareCode || "");
  if (_gm_isOfficial(id)) return "official";
  return "xhs";
}

function _xn_roomIdOf(payload) {
  var p = payload || {};
  var q = p.quality || {};
  var ctx = q.requestContext || {};
  var raw = _xn_str(p.roomId || p.id || q.roomId || ctx.roomId || p.url || p.shareCode || "");
  if (_gm_isOfficial(raw)) {
    var meta = _gm_find(raw);
    return meta ? meta.id : raw;
  }
  return _xn_requireRoom(p);
}

// ==================== Angel Live 导出接口 ====================

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  async clearCredential() {
    return {};
  },

  async getCategories() {
    var sub = [
      { id: "official", parentId: "xhs_news", title: "官媒直通 · 官网固定源", icon: "", biz: "official" },
      { id: "cctv_all", parentId: "xhs_news", title: "央视全频道", icon: "", biz: "cctv_all" },
      { id: "xhs_all",  parentId: "xhs_news", title: "小红书原播（需房号）", icon: "", biz: "xhs_all" }
    ];
    for (var i = 0; i < _gm_official.length; i++) {
      sub.push({
        id: _gm_official[i].id, parentId: "xhs_news",
        title: _gm_official[i].name + " · 官网源", icon: "", biz: _gm_official[i].id
      });
    }
    return [{ id: "xhs_news", title: "官媒直播", icon: "", biz: "xhs_news", subList: sub }];
  },

  async getRooms(payload) {
    var p = payload || {};
    var page = Math.max(1, Number(p.page) || 1);
    if (page > 1) return [];
    var cat = _xn_str(p.childId || p.id || p.categoryId || p.parentBiz || p.biz || "").trim();

    // 默认（无分类 / all / official / 父级）→ 6 个官媒官网固定源
    if (!cat || cat === "all" || cat === "official" || /xhs_news/i.test(cat)) {
      return _gm_rooms(_gm_official);
    }
    if (cat === "cctv_all") return _gm_rooms(_gm_allChannels());

    // 单个官媒 / 单个央视频道
    var single = _gm_find(cat);
    if (single) return _gm_rooms([single]);

    // 小红书原播（含旧版 6 个频道 id，保持升级兼容）
    if (cat === "xhs_all") {
      await _xn_loadRemote(false);
      var infos = await Promise.all(_xn_channels.map(function (ch) {
        return _xn_resolveChannel(ch).catch(function () { return null; });
      }));
      var out = [];
      for (var j = 0; j < _xn_channels.length; j++) out.push(_xn_roomDTO(_xn_channels[j], infos[j]));
      return out;
    }
    var xhsCh = _xn_channelById(cat);
    if (xhsCh) {
      await _xn_loadRemote(false);
      var info = await _xn_resolveChannel(xhsCh).catch(function () { return null; });
      return [_xn_roomDTO(xhsCh, info)];
    }
    return _gm_rooms(_gm_official);
  },

  async getRoomDetail(payload) {
    if (_xn_kind(payload) === "official") {
      var meta = _gm_find(_xn_roomIdOf(payload));
      if (!meta) _xn_throw("NOT_FOUND", "未知官网频道", {});
      var epg = await _gm_fetchEPG(meta.lines[0]).catch(function () { return null; });
      return _gm_roomDTO(meta, epg);
    }
    var id = _xn_requireRoom(payload);
    var info = null;
    try { info = await _xn_fetchRoom(id); } catch (e) { info = null; }
    var ch = _xn_channelByRoomId(id) || {
      id: id, name: (info && info.host) || "小红书直播",
      roomId: id, candidates: [id], learned: false, stale: false
    };
    return _xn_roomDTO(ch, info);
  },

  async getLiveState(payload) {
    if (_xn_kind(payload) === "official") {
      var meta = _gm_find(_xn_roomIdOf(payload));
      if (!meta) return { liveState: "0", roomId: "" };
      var v = await _gm_fetchVDN(meta.lines[0], true).catch(function () { return null; });
      return { liveState: v && v.streams.length ? "1" : "0", roomId: meta.id };
    }
    var id = _xn_requireRoom(payload);
    var info = null;
    try { info = await _xn_fetchRoom(id, true); } catch (e) { info = null; }
    return { liveState: _xn_usable(info) ? "1" : "0", roomId: id };
  },

  async getPlayback(payload) {
    if (_xn_kind(payload) === "official") {
      return _gm_playbackLines(_xn_roomIdOf(payload));
    }
    var id = _xn_requireRoom(payload);
    var info = await _xn_fetchRoom(id, true);
    if (!_xn_usable(info)) {
      _xn_throw("NOT_LIVE",
        "该小红书直播间已下播或房号已失效。建议切到「官媒直通 · 官网固定源」分类（频道号固定、不用维护）。",
        { roomId: id, diag: _xn_lastErr, upstream: info && info.error ? info.error : "" });
    }
    return _xn_playbackLines(info);
  },

  // 宿主约定：refreshPlayback 返回「单个清晰度对象」，不是线路数组。
  async refreshPlayback(payload) {
    var p = payload || {};
    var q = p.quality || {};
    var ctx = q.requestContext || {};

    if (ctx.source === "cctv_vdn" || _gm_isOfficial(_xn_str(p.roomId || q.roomId || ctx.roomId || ""))) {
      var roomId = _xn_roomIdOf(p);
      var lines = await _gm_playbackLines(roomId);
      var wantCh = _xn_str(ctx.ch);
      var wantLine = _xn_str(ctx.line);
      var wantTitle = _xn_str(q.title);
      var best = null;
      for (var i = 0; i < lines.length; i++) {
        for (var j = 0; j < lines[i].qualitys.length; j++) {
          var item = lines[i].qualitys[j];
          var ic = item.requestContext || {};
          if (!best) best = item;
          if (wantTitle && item.title === wantTitle) return item;
          if (wantCh && ic.ch === wantCh && (!wantLine || ic.line === wantLine)) return item;
        }
      }
      if (best) return best;
      _xn_throw("NOT_LIVE", "官网未返回可播放流", { roomId: roomId });
    }

    var id = _xn_extractRoomId(_xn_str(p.roomId || q.roomId || ctx.roomId || ""));
    if (!id) _xn_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    var info = await _xn_fetchRoom(id, true);
    if (!_xn_usable(info)) {
      _xn_throw("NOT_LIVE", "小红书未返回可播放流（房号可能已失效，建议改用官网固定源）", { roomId: id, diag: _xn_lastErr });
    }
    var line = _xn_str(ctx.line || p.line || "hls");
    var want = _xn_str(q.title);
    var pick = null;
    for (var k = 0; k < info.streams.length; k++) {
      var s = info.streams[k];
      var matchLine = (line === "hls") ? _xn_isHLS(s.url) : !_xn_isHLS(s.url);
      if (!matchLine) continue;
      var candidateTitle = (s.label || "原画") + " · " + (line === "hls" ? "HLS" : "FLV");
      if (!pick) pick = { s: s, title: candidateTitle };
      if (want && (want.indexOf(s.label || "原画") >= 0 ||
          (line === "flv" && want.indexOf("备线") >= 0 && /bak-/.test(s.url)))) {
        pick = { s: s, title: candidateTitle };
        break;
      }
    }
    if (!pick) pick = { s: info.streams[0], title: (info.streams[0].label || "原画") };
    var type = _xn_isHLS(pick.s.url) ? "m3u8" : "flv";
    return _xn_quality(id, pick.s.url, type, pick.title, Number(q.qn) || 1, type === "m3u8" ? "hls" : "flv");
  },

  // 支持：官媒名 / cctv 频道名 / 央视直播页链接 / 小红书分享链接 / 纯房号
  async search(payload) {
    var kw = _xn_str(payload && (payload.keyword || payload.q || payload.query || payload)).trim();
    if (!kw) return [];

    // 央视直播页链接 / 纯频道号 → 对应官网频道
    var tv = /tv\.cctv\.com\/live\/(cctv\d+)/i.exec(kw) || /(?:^|[^a-z])(cctv\d{1,2})(?:$|[^0-9])/i.exec(kw);
    if (tv) {
      var ch = tv[1].toLowerCase();
      if (_gm_known(ch)) {
        var m = _gm_find("tv_" + ch);
        var epg = await _gm_fetchEPG(ch).catch(function () { return null; });
        return [_gm_roomDTO(m, epg)];
      }
    }
    // 「CCTV-13 新闻」「CCTV13」这类带连字符的频道名 → 精确落到对应官网频道，
    // 否则会被官媒别名里宽泛的 "CCTV" 抢先命中成「央视网」。
    var no = /CCTV[-\s]?(\d{1,2})/i.exec(kw);
    if (no) {
      var ch3 = "cctv" + no[1];
      if (_gm_known(ch3)) {
        var m3 = _gm_find("tv_" + ch3);
        var e3 = await _gm_fetchEPG(ch3).catch(function () { return null; });
        return [_gm_roomDTO(m3, e3)];
      }
    }

    // 小红书链接 / 纯房号 → 走原播（并触发房号学习）
    var id = _xn_extractRoomId(kw);
    if (id && /livestream|room_id|^\d+$|xhsdiscover/i.test(kw)) {
      await _xn_loadRemote(false);
      var info = null;
      try { info = await _xn_fetchRoom(id, true); } catch (e) { info = null; }
      var xch = _xn_channelByRoomId(id) || {
        id: id, name: (info && info.host) || "小红书直播",
        roomId: id, candidates: [id], learned: false, stale: !_xn_usable(info)
      };
      return [_xn_roomDTO(xch, info)];
    }

    // 官媒名 / 频道名 → 官网固定源
    var matched = [];
    for (var i = 0; i < _gm_official.length; i++) {
      var o = _gm_official[i];
      var hit = o.name.indexOf(kw) >= 0 || kw.indexOf(o.name) >= 0;
      if (!hit) {
        for (var a = 0; a < o.aliases.length; a++) {
          if (o.aliases[a].indexOf(kw) >= 0 || kw.indexOf(o.aliases[a]) >= 0) { hit = true; break; }
        }
      }
      if (hit) matched.push(o);
    }
    if (!matched.length) {
      for (var c = 0; c < _gm_cctvChannels.length; c++) {
        var cc = _gm_cctvChannels[c];
        if (cc.name.indexOf(kw) >= 0) {
          matched.push({ id: "tv_" + cc.ch, name: cc.name, aliases: [cc.ch], lines: [cc.ch] });
        }
      }
    }
    if (matched.length) return _gm_rooms(matched);

    // 兼容旧版：小红书频道名搜索
    await _xn_loadRemote(false);
    var out = [];
    for (var t = 0; t < _xn_channels.length; t++) {
      var xc = _xn_channels[t];
      var ok = xc.name.indexOf(kw) >= 0 || kw.indexOf(xc.name) >= 0;
      if (!ok) {
        for (var b = 0; b < xc.aliases.length; b++) {
          if (xc.aliases[b].indexOf(kw) >= 0 || kw.indexOf(xc.aliases[b]) >= 0) { ok = true; break; }
        }
      }
      if (!ok) continue;
      var ci = await _xn_resolveChannel(xc).catch(function () { return null; });
      out.push(_xn_roomDTO(xc, ci));
    }
    return out;
  },

  async resolveShare(payload) {
    var p = payload || {};
    var text = _xn_str(p.shareCode || p.url || p.text || p).trim();
    if (!text) _xn_throw("INVALID_ARGS", "shareCode is required", { field: "shareCode" });

    var tv = /tv\.cctv\.com\/live\/(cctv\d+)/i.exec(text);
    if (tv) {
      var ch = tv[1].toLowerCase();
      var m = _gm_find("tv_" + ch);
      if (m) {
        var epg = await _gm_fetchEPG(ch).catch(function () { return null; });
        return _gm_roomDTO(m, epg);
      }
    }

    var id = _xn_extractRoomId(text);
    if (!id) {
      _xn_throw("NOT_FOUND", "没有在分享内容里找到直播间号或央视直播页链接", { shareCode: text.slice(0, 120) });
    }
    var info = null;
    try { info = await _xn_fetchRoom(id, true); } catch (e) { info = null; }
    var ch2 = _xn_channelByRoomId(id) || {
      id: id, name: (info && info.host) || "小红书直播",
      roomId: id, candidates: [id], learned: false, stale: !_xn_usable(info)
    };
    return _xn_roomDTO(ch2, info);
  }
};
