// Angel Live 插件：小红书 · 官媒直播  A 版 v3.0.0
//
// 本版【彻底删除 B 方案】：没有任何电视频道号、没有官网信号、没有节目单、没有 CDN 探测。
// 只剩小红书原播，6 个官媒各绑定一个稳定的【主播主页 ID】。
//
// 播放（实测可用，零登录零签名）：
//   GET https://www.xiaohongshu.com/livestream/<roomId>?source=web_live_list
//   UA = iPhone Safari, Referer = https://app.xhs.cn/
//   → SSR 的 liveStream.roomData.roomInfo.pullConfig → h264[].master_url（原画 HLS + 3 路 FLV）
//
// A 版核心：homeId（主播主页 ID）永不随开播变化。
//   ① 有登录态时先请求主播主页 SSR 找本次开播的 livestream 房号；
//   ② 找到就自动顶到房号池首位，房号换了也能自动跟上；
//   ③ 找不到就回退房号池（rooms.json 热更新 / 用户粘贴直播链接自动学习）。
// 小红书 Web 端没有免签名的「主页 ID → 当前房号」公开接口，
// 因此登录态能提高自动发现命中率；凭证只从 Host.session 读，绝不写进插件包。

var _xn_platformId = "xhs-news";
var _xn_liveType = "11";
var _xn_ua = "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1";
var _xn_referer = "https://app.xhs.cn/";
var _xn_base = "https://www.xiaohongshu.com/livestream/";
// 房号表多镜像：手机 5G 下某个 CDN 不通时自动换下一个
var _xn_roomsURLs = [
  "https://gcore.jsdelivr.net/gh/gaoshangshuai/angel-plugins@main/rooms-a.json",
  "https://cdn.jsdelivr.net/gh/gaoshangshuai/angel-plugins@main/rooms-a.json",
  "https://gcore.jsdelivr.net/gh/gaoshangshuai/angel-plugins@main/rooms.json",
  "https://cdn.jsdelivr.net/gh/gaoshangshuai/angel-plugins@main/rooms.json"
];
var _xn_remoteTTL = 300000;   // 5 分钟重拉一次，线上改表免重启生效
var _xn_maxCandidates = 8;    // 每个频道最多保留的历史房号数

// 6 个官媒频道。hostId 是稳定的主播 ID（不会随开播变化），仅作记录 / 未来扩展。
// candidates = 房号池，roomId = 当前选中；learned = 本次运行由分享链接学到。
var _xn_channels = [
  { id: "cctv",    name: "央视网",   aliases: ["央视网", "CCTV", "央视"],   homeId: "6470182e000000002a03454a", homeUrl: "", candidates: ["570559521790467377"], roomId: "570559521790467377", learned: false, stale: false },
  { id: "kuaikan", name: "快看",     aliases: ["快看", "新华社快看"],       homeId: "6407d96c000000001f032ae5", homeUrl: "https://xhslink.cn/o/6yaZwrcrzWG", candidates: [], roomId: "", learned: false, stale: false },
  { id: "ckxx",    name: "参考消息", aliases: ["参考消息"],                 homeId: "63c6460a0000000026007fcd", homeUrl: "https://xhslink.cn/o/KsBOj0CdnQ", candidates: [], roomId: "", learned: false, stale: false },
  { id: "ysp",     name: "央视频",   aliases: ["央视频"],                   homeId: "5eac59390000000001006d11", homeUrl: "https://xhslink.cn/o/3cqsBWDriX0", candidates: [], roomId: "", learned: false, stale: false },
  { id: "xhw",     name: "新华网",   aliases: ["新华网", "新华社"],         homeId: "63301151000000002303b082", homeUrl: "https://xhslink.cn/o/7K2hbaZI3rT", candidates: [], roomId: "", learned: false, stale: false },
  { id: "xxqg",    name: "学习强国", aliases: ["学习强国"],                 homeId: "6790bdb1000000000403718b", homeUrl: "https://xhslink.cn/o/NDMr7OX0R0", candidates: [], roomId: "", learned: false, stale: false }
];

var _xn_roomCache = {};       // roomId -> room info（30 秒内复用）
var _xn_remoteTs = 0;         // 上次拉取房号表的时间戳（含失败，避免反复拖慢）
var _xn_lastErr = "";

// ==================== 基础工具 ====================

function _xn_str(v) {
  return v === undefined || v === null ? "" : String(v);
}

function _xn_throw(code, message, context) {
  var ctx = context || {};
  if (globalThis.Host && typeof Host.raise === "function") Host.raise(code, message, ctx);
  if (globalThis.Host && typeof Host.makeError === "function") {
    throw Host.makeError(code || "UNKNOWN", message || "", ctx);
  }
  throw new Error("LP_PLUGIN_ERROR:" + JSON.stringify({
    code: String(code || "UNKNOWN"), message: String(message || ""), context: ctx
  }));
}

// 从任意输入中抠出小红书直播间号：
//   分享链接 /livestream/<id>?xsec_token=...
//   两段式   /livestream/<dynPathToken>/<id>
//   App 深链 xhsdiscover://live_audience?room_id=<id>
//   流地址   /live/<id>.flv 或 .m3u8
//   纯 15~20 位数字
function _xn_extractRoomId(text) {
  var t = _xn_str(text);
  if (!t) return "";
  var pats = [
    /livestream\/([0-9]{10,24})/i,
    /livestream\/[^/?#\s]+\/([0-9]{10,24})/i,
    /room_id[=:]([0-9]{10,24})/i,
    /\/live\/([0-9]{10,24})\.(?:flv|m3u8)/i,
    /(?:\D|^)([0-9]{15,20})(?:\D|$)/,
    /^([0-9]{10,24})$/
  ];
  for (var i = 0; i < pats.length; i++) {
    var m = pats[i].exec(t);
    if (m && m[1]) return m[1];
  }
  return "";
}

function _xn_channelById(id) {
  for (var i = 0; i < _xn_channels.length; i++) {
    if (_xn_channels[i].id === id) return _xn_channels[i];
  }
  return null;
}

// 从 payload 里取房间号；遇到「未绑定 / 已失效」给出可操作指引。
function _xn_requireRoom(payload) {
  var p = payload || {};
  var raw = _xn_str(p.roomId || p.url || p.shareCode || (p.quality && p.quality.roomId) || "");
  var id = _xn_extractRoomId(raw);
  if (id) return id;

  var cid = _xn_str(p.roomId || p.id || "").trim();
  var ch = _xn_channelById(cid);
  if (ch && !ch.roomId) {
    if (ch.homeId) {
      // 已绑定主页但当前没房号：告诉用户「已绑定、未开播」，别误显示成没绑定
      _xn_throw("NOT_LIVE",
        "「" + ch.name + "」已绑定主播主页，但当前没有正在进行的直播（小红书主页未下发房号）。开播后插件会自动找新房号，也可以把该账号的直播分享链接粘贴到搜索框立即观看。",
        { channel: ch.id, homeId: ch.homeId });
    }
    _xn_throw("NOT_FOUND",
      "「" + ch.name + "」还没绑定。请在小红书 App 打开该账号主页 → 分享 → 复制链接，粘贴到本 App 搜索框；插件会提取稳定的主页 ID 与当前直播房号并自动绑定。",
      { channel: ch.id });
  }
  if (ch && ch.stale) {
    _xn_throw("NOT_FOUND",
      "「" + ch.name + "」的房号已失效（小红书每次开播会换房间号）。请粘贴该账号最新的直播分享链接，插件会自动更新。",
      { channel: ch.id, staleRoomId: ch.roomId });
  }
  if (ch && ch.roomId) return ch.roomId;   // 宿主用频道 id 进来时也能正确播放
  _xn_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
  return "";
}

// ==================== 宿主网络层 ====================

// Host.http.request({url,method,headers,timeout}) → {status,headers,bodyText}
async function _xn_request(url, timeout, cookie) {
  if (!globalThis.Host || !Host.http || typeof Host.http.request !== "function") {
    _xn_throw("UNSUPPORTED", "Host.http.request is unavailable", {});
  }
  var headers = {
    "User-Agent": _xn_ua,
    "Referer": _xn_referer,
    "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Cache-Control": "no-cache"
  };
  if (cookie) headers["Cookie"] = _xn_str(cookie);
  var raw = await Host.http.request({
    url: url,
    method: "GET",
    headers: headers,
    timeout: timeout || 15
  });
  var res = raw;
  if (typeof raw === "string") {
    try { res = JSON.parse(raw); } catch (e) { res = { bodyText: raw }; }
  }
  return res || {};
}

// 括号配对扫描，从 SSR 文本里切出 "liveStream":{...} 的完整对象。
// 必须处理字符串里的转义引号与花括号，否则 pullConfig（内含 JSON 字符串）会截断。
function _xn_extractObj(text, key) {
  var k = '"' + key + '"';
  var i = text.indexOf(k);
  if (i < 0) return null;
  var start = text.indexOf("{", i + k.length);
  if (start < 0) return null;
  var depth = 0, inStr = false, esc = false;
  for (var j = start; j < text.length; j++) {
    var ch = text.charAt(j);
    if (inStr) {
      if (esc) esc = false;
      else if (ch === "\\") esc = true;
      else if (ch === '"') inStr = false;
    } else {
      if (ch === '"') inStr = true;
      else if (ch === "{") depth++;
      else if (ch === "}") {
        depth--;
        if (depth === 0) return text.slice(start, j + 1);
      }
    }
  }
  return null;
}

// SSR 的 INITIAL_STATE 里混有 undefined 字面量（不是合法 JSON），先归一化再解析。
function _xn_parseLive(html) {
  var objText = _xn_extractObj(html, "liveStream");
  if (!objText) return null;
  try {
    return JSON.parse(objText.replace(/\bundefined\b/g, "null"));
  } catch (e) {
    return null;
  }
}

function _xn_isHLS(url) {
  return /\.m3u8(?:[?#]|$)/i.test(_xn_str(url));
}

// pullConfig 是一个 JSON 字符串；浏览器把 "/" 写成 \u002F，JSON.parse 会自动还原。
function _xn_streams(live) {
  var rd = live && live.roomData;
  var ri = rd && rd.roomInfo;
  var out = [];
  if (!ri) return out;

  var pc = null;
  try {
    if (typeof ri.pullConfig === "string") pc = JSON.parse(ri.pullConfig);
    else if (ri.pullConfig && typeof ri.pullConfig === "object") pc = ri.pullConfig;
  } catch (e) { pc = null; }

  if (pc && pc.h264 && pc.h264.length) {
    for (var i = 0; i < pc.h264.length; i++) {
      var u = _xn_str(pc.h264[i] && pc.h264[i].master_url);
      if (u) out.push({ url: u, label: _xn_str(pc.h264[i].quality_type_name) || "原画" });
    }
  }
  // 兜底：deeplink 里的 flvUrl 参数
  if (!out.length) {
    var m = /flvUrl=([^&]+)/.exec(_xn_str(ri.deeplink));
    if (m) {
      try { out.push({ url: decodeURIComponent(m[1]), label: "原画" }); } catch (e) { }
    }
  }
  return out;
}

// ==================== A 版：主页 ID 绑定 ====================

async function _xa_cookie() {
  try {
    if (globalThis.Host && Host.session && typeof Host.session.getCookieHeader === "function") {
      var c = await Host.session.getCookieHeader("xiaohongshu");
      if (!c) c = await Host.session.getCookieHeader("xhs-news");
      return _xn_str(c || "");
    }
  } catch (e) { /* 匿名模式照样能播 */ }
  return "";
}

function _xa_extractHomeId(text) {
  var m = /user\/profile\/([0-9a-f]{24})/i.exec(_xn_str(text));
  return m ? m[1] : "";
}

// 读取响应头（大小写不敏感）：短链 302 需要手动跟随，不依赖宿主是否自动重定向。
function _xa_header(res, name) {
  var h = (res && res.headers) || {};
  var keys = Object.keys(h);
  for (var i = 0; i < keys.length; i++) {
    if (keys[i].toLowerCase() === name.toLowerCase()) return _xn_str(h[keys[i]]);
  }
  return "";
}

// 带 302 跟随的 GET，返回最终 HTML 文本。
async function _xa_get(url, cookie) {
  var cur = url;
  for (var hop = 0; hop < 4; hop++) {
    var res = await _xn_request(cur, 8, cookie);
    var st = Number(res && res.status) || 0;
    var loc = _xa_header(res, "Location");
    if (st >= 300 && st < 400 && loc) {
      cur = /^https?:/i.test(loc)
        ? loc
        : "https://www.xiaohongshu.com" + (loc.charAt(0) === "/" ? loc : "/" + loc);
      continue;
    }
    return _xn_str(res && res.bodyText);
  }
  return "";
}

// 从主播主页 SSR 里找本次开播的房号。
// 覆盖：直播页链接 / roomId 系列字段 / 直播动态组件 businessId / deepLink 里的 room_id。
// 只认明确字段，避免把粉丝数、时间戳等无关数字误当房号。
function _xa_extractRoomFromHome(html) {
  var t = _xn_str(html);
  if (!t) return "";
  var pats = [
    /livestream\/([0-9]{10,24})/,
    /"roomId"\s*:\s*"?([0-9]{10,24})/i,
    /"room_id"\s*:\s*"?([0-9]{10,24})/i,
    /"liveRoomId"\s*:\s*"?([0-9]{10,24})/i,
    /"liveId"\s*:\s*"?([0-9]{10,24})/i,
    /"businessId"\s*:\s*"([0-9]{10,24})"/,
    /room_id=([0-9]{10,24})/i,
    /live_id=([0-9]{10,24})/i
  ];
  for (var i = 0; i < pats.length; i++) {
    var m = pats[i].exec(t);
    if (m && m[1]) return m[1];
  }
  return "";
}

// 用户粘贴「@快看 在小红书… https://xhslink.cn/o/xxx」这类整段口令时，
// 按链接前的账号名把主页 ID / 主页短链绑定到对应频道。
function _xa_bindFromText(text) {
  var t = _xn_str(text);
  if (!t) return 0;
  var bound = 0;
  var re = /https?:\/\/[^\s;；，,）)"']+/g;
  var m;
  while ((m = re.exec(t)) !== null) {
    var link = m[0];
    if (!/xhslink\.cn|xiaohongshu\.com/.test(link)) continue;
    var before = t.slice(Math.max(0, m.index - 90), m.index);
    var target = null, bestPos = -1;
    for (var i = 0; i < _xn_channels.length; i++) {
      var ch = _xn_channels[i];
      for (var k = 0; k < ch.aliases.length; k++) {
        var p = before.lastIndexOf(ch.aliases[k]);
        if (p > bestPos) { bestPos = p; target = ch; }
      }
    }
    if (!target) continue;
    var hid = _xa_extractHomeId(link);
    if (hid) target.homeId = hid;
    if (/xhslink\.cn\/o\//.test(link) || /user\/profile\//.test(link)) target.homeUrl = link;
    delete _xa_homeTs[target.id];
    bound++;
  }
  return bound;
}

var _xa_homeTs = {};
async function _xa_homeToRoom(ch) {
  if (!ch || (!ch.homeId && !ch.homeUrl)) return null;
  var now = Date.now();
  if (_xa_homeTs[ch.id] && now - _xa_homeTs[ch.id] < 120000) return null;
  _xa_homeTs[ch.id] = now;
  var cookie = await _xa_cookie();
  var urls = [];
  if (ch.homeUrl) urls.push(ch.homeUrl);
  // 没有短链可用时，匿名请求主播主页只会拿到空壳；只有带登录态才值得试。
  if (ch.homeId && cookie) {
    urls.push("https://www.xiaohongshu.com/user/profile/" + ch.homeId + "?channel_type=web_user_page&tab=live");
    urls.push("https://www.xiaohongshu.com/user/profile/" + ch.homeId);
  }
  if (!urls.length) return null;
  for (var i = 0; i < urls.length; i++) {
    try {
      var html = await _xa_get(urls[i], cookie);
      var room = _xa_extractRoomFromHome(html);
      if (room) return room;
      // 已经拿到完整主页 SSR 却没有房号 = 该账号当前没在播，别再试空壳入口拖慢列表
      if (html.length > 5000) break;
    } catch (e) { /* 换下一个入口 */ }
  }
  return null;
}

// ==================== 房间数据 ====================

async function _xn_fetchRoom(roomId, force) {
  var now = Date.now();
  var cached = _xn_roomCache[roomId];
  if (!force && cached && now - cached.ts < 30000) return cached;

  var url = _xn_base + encodeURIComponent(roomId) + "?source=web_live_list";
  var res = await _xn_request(url, 15);
  var html = _xn_str(res && res.bodyText);
  if (!html) { _xn_lastErr = "empty response"; return null; }

  var live = _xn_parseLive(html);
  if (!live) { _xn_lastErr = "liveStream not found in SSR"; return null; }

  var rd = live.roomData || {};
  var ri = rd.roomInfo || {};
  var hi = rd.hostInfo || {};
  var status = Number(ri.status || 0);
  var info = {
    roomId: _xn_str(ri.roomId) || roomId,
    title: _xn_str(ri.roomTitle),
    cover: _xn_str(ri.roomCover),
    host: _xn_str(hi.nickName),
    avatar: _xn_str(hi.avatar),
    viewers: _xn_str(ri.displayViewerCount),
    status: status,
    liveState: status === 2 ? "1" : "0",
    pageStatus: _xn_str(live.pageStatus),
    error: _xn_str(live.errorMessage),
    streams: _xn_streams(live),
    ts: now
  };
  _xn_roomCache[roomId] = info;
  _xn_learn(info);   // 主播昵称命中官媒名单时，自动把房号顶到房号池首位
  return info;
}

// 一个房号「可用」= SSR 判定直播中且确实拿到流。下播 / 房号失效时 streams 为空。
function _xn_usable(info) {
  return !!(info && info.liveState === "1" && info.streams && info.streams.length);
}

// 房号池：把一个 roomId 加入候选（去重），front=true 插到最前。
function _xn_pushCandidate(ch, value, front) {
  var id = _xn_extractRoomId(value);
  if (!id) return false;
  var arr = ch.candidates;
  for (var i = 0; i < arr.length; i++) {
    if (arr[i] === id) {
      if (front && i > 0) { arr.splice(i, 1); arr.unshift(id); }
      return false;
    }
  }
  if (front) arr.unshift(id); else arr.push(id);
  if (arr.length > _xn_maxCandidates) arr.length = _xn_maxCandidates;
  return true;
}

// 分享链接自动学习：SSR 返回真实主播昵称（例如「央视网」），据此点亮对应频道，
// 并把新房号顶到候选池首位 —— 这样房号换了，粘贴一次链接就能自动追上。
function _xn_learn(info) {
  if (!_xn_usable(info) || !info.host || !info.roomId) return null;
  var h = info.host;
  for (var i = 0; i < _xn_channels.length; i++) {
    var ch = _xn_channels[i];
    for (var k = 0; k < ch.aliases.length; k++) {
      var a = ch.aliases[k];
      if (h.indexOf(a) >= 0 || (a.length > 1 && a.indexOf(h) >= 0)) {
        // 只有房号真的变了才标「新」，内置 / 线上表里已有的房号不显示误导性提示
        var changed = ch.roomId !== info.roomId;
        _xn_pushCandidate(ch, info.roomId, true);
        ch.roomId = info.roomId;
        if (changed) ch.learned = true;
        ch.stale = false;
        return ch;
      }
    }
  }
  return null;
}

// rooms.json 支持四种写法（手机上手填最方便的是第 1、2 种）：
//   "cctv": "570559521790467377"
//   "cctv": "https://www.xiaohongshu.com/livestream/570...?..."   // 直接粘分享链接
//   "cctv": ["旧房号", "新房号", "分享链接"]                        // 房号池
//   "cctv": { "hostId": "...", "roomIds": ["..."], "url": "..." }  // 完整元数据
function _xn_parseChannelValue(v) {
  var ids = [];
  function add(x) {
    if (x === undefined || x === null || typeof x === "object") return;
    var id = _xn_extractRoomId(_xn_str(x));
    if (id && ids.indexOf(id) < 0) ids.push(id);
  }
  if (Array.isArray(v)) {
    for (var i = 0; i < v.length; i++) add(v[i]);
  } else if (v && typeof v === "object") {
    var keys = ["roomId", "room_id", "url", "link", "pinned"];
    for (var k = 0; k < keys.length; k++) add(v[keys[k]]);
    var lists = ["roomIds", "rooms", "candidates", "history"];
    for (var m = 0; m < lists.length; m++) {
      var arr = v[lists[m]];
      if (Array.isArray(arr)) for (var n = 0; n < arr.length; n++) add(arr[n]);
    }
  } else {
    add(v);
  }
  return ids;
}

// 远程房号表：每 5 分钟重拉一次。主 CDN 不通自动换镜像；拉不到静默用本地池。
// 线上表更新后，设备无需重装插件、无需重启 App，5 分钟内自动拿到新房号。
async function _xn_loadRemote(force) {
  var now = Date.now();
  if (!force && _xn_remoteTs && now - _xn_remoteTs < _xn_remoteTTL) return;
  _xn_remoteTs = now;

  var data = null;
  for (var u = 0; u < _xn_roomsURLs.length && !data; u++) {
    try {
      var res = await _xn_request(_xn_roomsURLs[u], 8);
      var txt = _xn_str(res && res.bodyText).trim();
      if (txt.charAt(0) !== "{") continue;
      data = JSON.parse(txt);
    } catch (e) { /* 换下一个镜像 */ }
  }
  if (!data) return;

  var map = data.channels || data.rooms || {};
  var hosts = data.hosts || {};
  var homeUrls = data.homeUrls || {};
  for (var i = 0; i < _xn_channels.length; i++) {
    var ch = _xn_channels[i];
    // 修复：之前误写进 hostId，导致线上表里的主页 ID 完全没生效。
    // hosts 里可以是纯 24 位 ID，也可以直接粘完整主页链接 / 短链。
    var hv = _xn_str(hosts[ch.id]);
    if (hv) {
      var hid = _xa_extractHomeId(hv) || (/^[0-9a-f]{24}$/i.test(hv) ? hv : "");
      if (hid) ch.homeId = hid;
      if (/^https?:/i.test(hv)) ch.homeUrl = hv;
    }
    var hu = _xn_str(homeUrls[ch.id]);
    if (hu) ch.homeUrl = hu;
    if (!(ch.id in map)) continue;

    var ids = _xn_parseChannelValue(map[ch.id]);
    if (!ids.length) continue;

    // 远程表是权威来源：房号入池，并把第一个作为「表指定房号」。
    // 但本次运行由分享链接学到的新房号优先（用户刚粘贴的一定是最新的）。
    for (var j = 0; j < ids.length; j++) _xn_pushCandidate(ch, ids[j], false);
    if (ch.learned) continue;
    if (ch.stale || !ch.roomId || ids.indexOf(ch.roomId) < 0) {
      ch.roomId = ids[0];
      ch.stale = false;
      // 表换了房号 → 让下次探测强制刷新，别用旧房号的 30 秒缓存
      delete _xn_roomCache[ch.roomId];
    }
  }
}

// 频道探活：先试当前房号；失效则依次试房号池里其它候选，命中就自动切换。
// 正常情况只发 1 个请求；只有房号真的换了才多发几个。
async function _xn_resolveChannel(ch) {
  var fresh = await _xa_homeToRoom(ch).catch(function () { return null; });
  if (fresh && fresh !== ch.roomId) {
    // 只有新房号确实能出流才切换，避免主页 SSR 里的无关数字把已绑定的频道带偏
    var probe = await _xn_fetchRoom(fresh, true).catch(function () { return null; });
    if (_xn_usable(probe)) {
      _xn_pushCandidate(ch, fresh, true);
      ch.roomId = fresh;
      ch.stale = false;
      ch.learned = true;
      delete _xn_roomCache[fresh];
    }
  }
  var ids = [];
  if (ch.roomId) ids.push(ch.roomId);
  for (var i = 0; i < ch.candidates.length; i++) {
    if (ids.indexOf(ch.candidates[i]) < 0) ids.push(ch.candidates[i]);
  }
  if (!ids.length) return null;

  for (var k = 0; k < ids.length; k++) {
    var info = null;
    try { info = await _xn_fetchRoom(ids[k], k > 0); } catch (e) { info = null; }
    if (_xn_usable(info)) {
      if (ch.roomId !== ids[k]) ch.learned = true;   // 自动从房号池切到新房间
      ch.roomId = ids[k];
      ch.stale = false;
      return info;
    }
  }
  ch.stale = !!ch.roomId || ch.candidates.length > 0;
  return null;
}

// ==================== 宿主 DTO ====================

// 字段严格对齐 PluginRoomDTO.swift
function _xn_roomDTO(ch, info) {
  var bound = !!(ch && ch.roomId);
  var title = info && info.title ? info.title : (ch ? ch.name : "小红书直播");
  if (!bound) {
    title = ch && ch.homeId
      ? ch.name + " · 已绑定主页 · 暂未开播（开播后自动找房号，也可粘贴直播分享链接）"
      : (ch ? ch.name : "小红书直播") + " · 粘贴该账号主页链接即可绑定";
  } else if (!info || ch.stale) {
    title = (ch ? ch.name : "小红书直播") + " · 房号已失效，请粘贴最新直播链接（小红书每次开播换房号）";
  } else if (ch.learned) {
    title = title + " · 新房号已记住（" + ch.roomId + "，填进 rooms.json 可长期生效）";
  }
  return {
    userName: (info && info.host) || (ch ? ch.name : "小红书直播"),
    roomTitle: title,
    roomCover: (info && info.cover) || "",
    userHeadImg: (info && info.avatar) || "",
    liveState: bound ? ((info && info.liveState) || "1") : "1",
    userId: ch ? ch.id : "",
    roomId: String(bound ? ch.roomId : (ch ? ch.id : "")),
    liveWatchedCount: (info && info.viewers) || ""
  };
}

function _xn_quality(roomId, url, type, title, qn, line) {
  return {
    roomId: String(roomId),
    title: title,
    qn: qn,
    url: url,
    liveCodeType: type,
    liveType: _xn_liveType,
    userAgent: _xn_ua,
    requestContext: { kind: type, source: "xhs_ssr", line: line, roomId: String(roomId) }
  };
}

function _xn_playbackLines(info) {
  var id = info.roomId;
  var hls = [], flv = [];
  for (var i = 0; i < info.streams.length; i++) {
    (_xn_isHLS(info.streams[i].url) ? hls : flv).push(info.streams[i]);
  }
  var lines = [];
  if (hls.length) {
    var hq = [];
    for (var a = 0; a < hls.length; a++) {
      hq.push(_xn_quality(id, hls[a].url, "m3u8", (hls[a].label || "原画") + " · HLS", a + 1, "hls"));
    }
    lines.push({
      cdn: "xhscdn",
      displayName: "小红书 · 原画 HLS（推荐）",
      requestContext: { roomId: id, kind: "hls", source: "xhs_ssr", line: "hls" },
      qualitys: hq
    });
  }
  if (flv.length) {
    var fq = [];
    for (var b = 0; b < flv.length; b++) {
      var u = flv[b].url;
      var label = /bak-tx/.test(u) ? "腾讯备线" : (/bak-hw/.test(u) ? "华为备线" : "主线路");
      fq.push(_xn_quality(id, u, "flv", (flv[b].label || "原画") + " · " + label, b + 1, "flv"));
    }
    lines.push({
      cdn: "xhscdn",
      displayName: "小红书 · FLV 备线",
      requestContext: { roomId: id, kind: "flv", source: "xhs_ssr", line: "flv" },
      qualitys: fq
    });
  }
  return lines;
}

// ==================== Angel Live 导出接口 ====================

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  async clearCredential() {
    return {};
  },

  async getCategories() {
    var sub = [{ id: "all", parentId: "xhs_news", title: "全部官媒（小红书原播）", icon: "", biz: "all" }];
    for (var i = 0; i < _xn_channels.length; i++) {
      sub.push({
        id: _xn_channels[i].id,
        parentId: "xhs_news",
        title: _xn_channels[i].name,
        icon: "",
        biz: _xn_channels[i].id
      });
    }
    return [{ id: "xhs_news", title: "小红书官媒直播", icon: "", biz: "xhs_news", subList: sub }];
  },

  async getRooms(payload) {
    var p = payload || {};
    var page = Math.max(1, Number(p.page) || 1);
    if (page > 1) return [];
    await _xn_loadRemote(false);

    var cat = _xn_str(p.childId || p.id || p.categoryId || p.parentBiz || p.biz || "").trim();
    var list = _xn_channels;
    if (cat && cat !== "all" && !/xhs_news/i.test(cat)) {
      var hit = _xn_channelById(cat);
      if (hit) list = [hit];
    }

    // 6 个频道并发探活，避免串行等待
    var infos = await Promise.all(list.map(function (ch) {
      return _xn_resolveChannel(ch).catch(function () { return null; });
    }));
    var out = [];
    for (var j = 0; j < list.length; j++) out.push(_xn_roomDTO(list[j], infos[j]));
    return out;
  },

  async getRoomDetail(payload) {
    var id = _xn_requireRoom(payload);
    var info = null;
    try { info = await _xn_fetchRoom(id); } catch (e) { info = null; }
    var ch = _xn_channelByRoomId(id) || { id: id, name: (info && info.host) || "小红书直播", roomId: id, candidates: [id], learned: false, stale: false };
    return _xn_roomDTO(ch, info);
  },

  async getLiveState(payload) {
    var id = _xn_requireRoom(payload);
    var info = null;
    try { info = await _xn_fetchRoom(id, true); } catch (e) { info = null; }
    return { liveState: _xn_usable(info) ? "1" : "0", roomId: id };
  },

  async getPlayback(payload) {
    var p = payload || {};
    var cid = _xn_str(p.roomId || p.id || "").trim();
    var pre = _xn_channelById(cid);
    if (pre && !pre.roomId && pre.homeId) {
      // 用户点进「暂未开播」卡片：绕开 2 分钟缓存，现场再查一次主播主页
      delete _xa_homeTs[pre.id];
      await _xn_resolveChannel(pre).catch(function () { return null; });
    }
    var id = _xn_requireRoom(p);
    var info = await _xn_fetchRoom(id, true);
    if (!_xn_usable(info)) {
      _xn_throw("NOT_LIVE",
        "该直播间已下播或房号已失效。小红书每次开播会换房间号：请在小红书 App 打开该账号直播 → 分享 → 复制链接 → 粘贴到本 App 搜索框，插件会自动更新房号。",
        { roomId: id, diag: _xn_lastErr, upstream: info && info.error ? info.error : "" });
    }
    return _xn_playbackLines(info);
  },

  // 宿主约定：refreshPlayback 返回「单个清晰度对象」，不是线路数组。
  // 按原线路（hls / flv）与原标题重新取一条新流。
  async refreshPlayback(payload) {
    var p = payload || {};
    var q = p.quality || {};
    var ctx = q.requestContext || {};
    var id = _xn_extractRoomId(_xn_str(p.roomId || q.roomId || ctx.roomId || ""));
    if (!id) _xn_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });

    var info = await _xn_fetchRoom(id, true);
    if (!_xn_usable(info)) {
      _xn_throw("NOT_LIVE", "小红书未返回可播放流（可能已下播或房号已失效，请粘贴最新直播链接）", { roomId: id, diag: _xn_lastErr });
    }
    var line = _xn_str(ctx.line || p.line || "hls");
    var wantTitle = _xn_str(q.title);
    var pick = null;

    for (var i = 0; i < info.streams.length; i++) {
      var s = info.streams[i];
      var matchLine = (line === "hls") ? _xn_isHLS(s.url) : !_xn_isHLS(s.url);
      if (!matchLine) continue;
      var candidateTitle = (s.label || "原画") + " · " + (line === "hls" ? "HLS" : "FLV");
      if (!pick) pick = { s: s, title: candidateTitle };
      if (wantTitle && (wantTitle.indexOf(s.label || "原画") >= 0 ||
          (line === "flv" && wantTitle.indexOf("备线") >= 0 && /bak-/.test(s.url)))) {
        pick = { s: s, title: candidateTitle };
        break;
      }
    }
    if (!pick) pick = { s: info.streams[0], title: (info.streams[0].label || "原画") };

    var type = _xn_isHLS(pick.s.url) ? "m3u8" : "flv";
    return _xn_quality(id, pick.s.url, type, pick.title, Number(q.qn) || 1, type === "m3u8" ? "hls" : "flv");
  },

  // 支持：频道名关键词、纯房间号、直播分享链接、App deeplink
  // 粘贴链接会触发「自动学习」：解析出主播昵称 → 新房号顶到对应频道首位。
  async search(payload) {
    var kw = _xn_str(payload && (payload.keyword || payload.q || payload.query || payload)).trim();
    if (!kw) return [];
    await _xn_loadRemote(false);

    var id = _xn_extractRoomId(kw);
    if (id) {
      var info = null;
      try { info = await _xn_fetchRoom(id, true); } catch (e) { info = null; }
      var ch = _xn_channelByRoomId(id) || { id: id, name: (info && info.host) || "小红书直播", roomId: id, candidates: [id], learned: false, stale: !_xn_usable(info) };
      return [_xn_roomDTO(ch, info)];
    }

    var out = [];
    for (var i = 0; i < _xn_channels.length; i++) {
      var c = _xn_channels[i];
      var matched = c.name.indexOf(kw) >= 0 || kw.indexOf(c.name) >= 0;
      if (!matched) {
        for (var k = 0; k < c.aliases.length; k++) {
          if (c.aliases[k].indexOf(kw) >= 0 || kw.indexOf(c.aliases[k]) >= 0) { matched = true; break; }
        }
      }
      if (!matched) continue;
      var ci = await _xn_resolveChannel(c);
      out.push(_xn_roomDTO(c, ci));
    }
    return out;
  },

  async resolveShare(payload) {
    var p = payload || {};
    var text = _xn_str(p.shareCode || p.url || p.text || p).trim();
    if (!text) _xn_throw("INVALID_ARGS", "shareCode is required", { field: "shareCode" });
    var id = _xn_extractRoomId(text);
    var boundCount = _xa_bindFromText(text);
    if (!id && boundCount) {
      var first = null;
      for (var b = 0; b < _xn_channels.length; b++) {
        if (text.indexOf(_xn_channels[b].name) >= 0) { first = _xn_channels[b]; break; }
      }
      if (first) return _xn_roomDTO(first, null);
    }
    if (!id) {
      var hid = _xa_extractHomeId(text);
      if (hid) {
        var target = null;
        for (var c = 0; c < _xn_channels.length; c++) {
          if (text.indexOf(_xn_channels[c].name) >= 0) { target = _xn_channels[c]; break; }
        }
        if (!target) {
          for (var d = 0; d < _xn_channels.length; d++) {
            if (!_xn_channels[d].homeId && !_xn_channels[d].roomId) { target = _xn_channels[d]; break; }
          }
        }
        if (target) {
          target.homeId = hid;
          delete _xa_homeTs[target.id];
          return _xn_roomDTO(target, null);
        }
      }
      _xn_throw("NOT_FOUND", "没找到直播间号或主播主页 ID。请粘贴小红书直播分享链接，或带 @账号名 的主页分享口令", { shareCode: text.slice(0, 120) });
    }
    var info = null;
    try { info = await _xn_fetchRoom(id, true); } catch (e) { info = null; }
    var ch = _xn_channelByRoomId(id) || { id: id, name: (info && info.host) || "小红书直播", roomId: id, candidates: [id], learned: false, stale: !_xn_usable(info) };
    return _xn_roomDTO(ch, info);
  }
};

// 按房号反查频道（详情 / 搜索 / 分享复用）；房号池里的历史房号也算命中。
function _xn_channelByRoomId(roomId) {
  for (var i = 0; i < _xn_channels.length; i++) {
    var ch = _xn_channels[i];
    if (ch.roomId && ch.roomId === roomId) return ch;
    for (var j = 0; j < ch.candidates.length; j++) {
      if (ch.candidates[j] === roomId) return ch;
    }
  }
  return null;
}
